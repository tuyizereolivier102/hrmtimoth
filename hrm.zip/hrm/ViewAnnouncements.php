<?php include('header.php'); ?>
<?php include_once('controller/connect.php'); ?>

<ol class="breadcrumb" style="margin: 10px 0px !important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>View Announcements</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <h2>Announcements</h2>

        <!-- Button to Add New Announcement -->
        <button onclick="showAddForm()" class="btn btn-success">Add New Announcement</button>

        <!-- Announcement List -->
        <ul id="announcementList">
            <!-- PHP code to fetch and display announcements goes here -->
            <?php
            $dbs = new database();
            $db = $dbs->connection();

            // Fetch announcements from the database
            $announcementsQuery = mysqli_query($db, "SELECT * FROM announcements");
            while ($row = mysqli_fetch_assoc($announcementsQuery)) {
                echo "<li>
                          <h3>{$row['title']}</h3>
                          <p>{$row['content']}</p>
                          <p>Expiration Date: {$row['expiration_date']}</p>
                          <button onclick=\"showEditForm('{$row['announcement_id']}', '{$row['title']}', '{$row['content']}', '{$row['expiration_date']}')\" class=\"btn btn-primary\">Edit</button>
                          <a href=\"controller/deleteAnnouncement.php?announcement_id={$row['announcement_id']}\" class=\"btn btn-danger\">Delete</a>
                       </li>";
            }
            ?>
        </ul>
    </div>
</div>

<!-- Add Announcement Form (hidden by default) -->
<div id="addForm" style="display: none;">
    <?php include('addAnnouncement.php'); ?>
</div>

<!-- Edit Announcement Form (hidden by default) -->
<div id="editForm" style="display: none;">
    <?php include('editAnnouncement.php'); ?>
</div>

<script>
    function showAddForm() {
        document.getElementById('addForm').style.display = 'block';
        document.getElementById('editForm').style.display = 'none';
    }

    function showEditForm(announcementId, title, content, expirationDate) {
        document.getElementById('addForm').style.display = 'none';
        document.getElementById('editForm').style.display = 'block';

        // Populate fields with the selected announcement data
        document.getElementById('editAnnouncementId').value = announcementId;
        document.getElementById('editTitle').value = title;
        document.getElementById('editContent').value = content;
        document.getElementById('editExpirationDate').value = expirationDate;
    }
</script>
<script>
    function editAnnouncement(announcementId) {
        // Implement your edit logic here
        // Display a popup form or redirect to editAnnouncement.php?announcement_id=announcementId
        // Here, we are redirecting to editAnnouncement.php with the announcement_id
        window.location.href = "editAnnouncement.php?announcement_id=" + announcementId;
    }

    function deleteAnnouncement(announcementId) {
        // Implement your delete logic here
        // Display a confirmation prompt and then redirect to deleteAnnouncement.php?announcement_id=announcementId
        var confirmation = confirm("Are you sure you want to delete this announcement?");
        if (confirmation) {
            window.location.href = "controller/deleteAnnouncement.php?announcement_id=" + announcementId;
        }
    }
</script>
<?php include('footer.php'); ?>
