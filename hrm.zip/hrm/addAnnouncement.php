
<?php
  include_once('controller/connect.php');
  
  $dbs = new database();
  $db=$dbs->connection();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["addAnnouncement"])) {
    $title = $_POST["title"];
    $content = $_POST["content"];
    $expirationDate = $_POST["expirationDate"];

    $insertQuery = "INSERT INTO announcements (title, content, expiration_date) VALUES ('$title', '$content', '$expirationDate')";
    mysqli_query($db, $insertQuery);

    // Add any additional logic or redirection as needed
}
