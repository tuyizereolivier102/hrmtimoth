<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hrm_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

session_start();

if (isset($_POST['submit'])) {
    $data = $_POST;
    $editid = 0;

    if (isset($_GET['empedit']) && $_GET['empedit'] > 0) {
        $editid = $_GET['empedit'];
    }
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assuming you have sanitized your input data to prevent SQL injection
$empid = $conn->real_escape_string($data['empid']);
$gender = $conn->real_escape_string($data['gender']);
$fname = $conn->real_escape_string($data['fname']);
$mname = $conn->real_escape_string($data['mname']);
$lname = $conn->real_escape_string($data['lname']);
$bdate = $conn->real_escape_string($data['bdate']);
$mnumber = $conn->real_escape_string($data['mnumber']);
$email = $conn->real_escape_string($data['email']);
$address2 = $conn->real_escape_string($data['cvfile']);
$address1 = $conn->real_escape_string($data['contractfile']);
$city = $conn->real_escape_string($data['city']);
$joindate = $conn->real_escape_string($data['joindate']);
$leavedate = $conn->real_escape_string($data['leavedate']);
$status = $conn->real_escape_string($data['status']);
$role = $conn->real_escape_string($data['role']);
$password = $conn->real_escape_string($data['password']);
$marital = $conn->real_escape_string($data['marital']);
$position = $conn->real_escape_string($data['position']);
$imagefilename = $conn->real_escape_string($data['ImageName']);

// Handle image upload
$imageDir = "images/"; // Specify the directory where you want to store the image
$imageFile = $imageDir . basename($_FILES["pfimg"]["name"]);
$imageSizeLimit = 5 * 1024 * 1024; // 5 MB limit

if ($_FILES["pfimg"]["size"] > $imageSizeLimit) {
    die("Error: Image file size exceeds the limit (5MB).");
}

// Upload the image
move_uploaded_file($_FILES["pfimg"]["tmp_name"], $imageFile);

// Handle PDF upload for contractfile
$pdfDir = "pdf_files/"; // Specify the directory where you want to store the PDF file
$pdfFile = $pdfDir . basename($_FILES["contractfile"]["name"]);
$pdfSizeLimit = 10 * 1024 * 1024; // 10 MB limit

if ($_FILES["contractfile"]["size"] > $pdfSizeLimit) {
    die("Error: PDF file size exceeds the limit (10MB).");
}

// Upload the PDF file
move_uploaded_file($_FILES["contractfile"]["tmp_name"], $pdfFile);

// SQL query to insert data into the database
$sql = "INSERT INTO employee values(null,'$empid','$fname','$mname','$lname','$bdate','$gender','$address1','$address2','$city','$mnumber','$email','$password','$aadharcard','$marital','$position','$roleid','$datetime',null,null,'$joindate','$leavedate',null,null,'$status','$role','$name','$macaddress')";

if ($conn->query($sql) === TRUE) {
    echo "Record inserted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
// Close the database connection
$conn->close();

?>
