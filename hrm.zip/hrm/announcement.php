<?php include('header.php'); ?>

<?php
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();
?>


<ol class="breadcrumb" style="margin: 10px 0px !important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Create/View Announcements</li>
</ol>

<div class="validation-system" style="margin-top: 0; display: flex;">
    <div class="validation-form" style="flex: 1;">
        <h2 id="formHeading">Create Announcement</h2>
        <form id="announcementForm" method="POST" action="controller/createAnnouncement.php">
            <!-- Hidden input for mode (create or edit) -->
            <input type="hidden" name="mode" id="mode" value="create">

            <!-- Announcement ID (for edit mode) -->
            <input type="hidden" name="editAnnouncementId" id="editAnnouncementId">

            <!-- Announcement Title -->
            <div class="col-md-6 control-label">
                <label class="control-label">Announcement Title</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-header" aria-hidden="true"></i>
                    </span>
                    <input type="text" name="title" class="form-control" placeholder="Enter announcement title" required>
                </div>
            </div>

            <!-- Announcement Content -->
            <div class="col-md-12 control-label">
                <label class="control-label">Announcement Content</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-align-left" aria-hidden="true"></i>
                    </span>
                    <textarea name="content" class="form-control" rows="5" placeholder="Enter announcement content"
                        required></textarea>
                </div>
            </div>

            <!-- Expiration Date (Optional) -->
            <div class="col-md-6 control-label">
                <label class="control-label">Expiration Date (Optional)</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-calendar" aria-hidden="true"></i>
                    </span>
                    <input type="date" name="expirationDate" class="form-control">
                </div>
            </div>

            <div class="col-md-12 form-group">
                <button type="submit" class="btn btn-primary">Save Announcement</button>
                <button type="reset" class="btn btn-default">Reset</button>
            </div>
            <div class="clearfix"></div>
        </form>
    </div>

    <div style="flex: 1;">
        <!-- Display Announcements in Table -->
        <h2>Announcement List</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Content</th>
                    <th>Expiration Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $announcementsQuery = mysqli_query($db, "SELECT * FROM announcements");
                while ($row = mysqli_fetch_assoc($announcementsQuery)) {
                    echo "<tr>
                            <td>{$row['title']}</td>
                            <td>{$row['content']}</td>
                            <td>{$row['expiration_date']}</td>
                            <td>
                                <button onclick=\"editAnnouncement('{$row['announcement_id']}', '{$row['title']}', '{$row['content']}', '{$row['expiration_date']}')\" class=\"btn btn-primary\">Edit</button>
                                <a href=\"controller/deleteAnnouncement.php?announcement_id={$row['announcement_id']}\" class=\"btn btn-danger\">Delete</a>
                            </td> <input type=\"hidden\" name=\"announcement_id\" value=\"{$row['announcement_id']}\">
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    function editAnnouncement(announcementId, title, content, expirationDate) {
        document.getElementById('mode').value = 'edit';
        document.getElementById('formHeading').innerText = 'Edit Announcement';
        
        // Populate fields with the selected announcement data
        document.getElementById('editAnnouncementId').value = announcementId;
        document.getElementById('announcementForm').elements['title'].value = title;
        document.getElementById('announcementForm').elements['content'].value = content;
        document.getElementById('announcementForm').elements['expirationDate'].value = expirationDate;
        
        // Switch to the create mode when canceling edit
        document.getElementById('announcementForm').elements['title'].focus();
    }
</script>

<?php include('footer.php'); ?>
