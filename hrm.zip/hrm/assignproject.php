<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Project to Employee</title>
    <style>
        

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 10px;
        }

        select, input {
            margin-bottom: 15px;
            padding: 8px;
        }
        .alert {
    padding: 15px;
    margin-bottom: 20px;
    border: 1px solid transparent;
    border-radius: 4px;
}

.alert.success {
    background-color: #dff0d8;
    border-color: #d6e9c6;
    color: #3c763d;
}

.alert.error {
    background-color: #f2dede;
    border-color: #ebccd1;
    color: #a94442;
}

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            padding: 10px;
            cursor: pointer;
            border: none;
            border-radius: 3px;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
        body {
    font-size: 18px; /* Increase the base font size */
}

.card {
    width: 70%; /* Adjust the width of the card */
    margin: 0 auto; /* Center the card on the page */
    margin-top: 50px; /* Add top margin for better spacing */
}



.table {
    font-size: 16px; /* Increase font size within the table */
}



        select {
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 3px;
    appearance: none; /* Remove default arrow in some browsers */
    background-image: url('data:image/svg+xml;utf8,<svg fill="%23444444" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z" /></svg>');
    background-repeat: no-repeat;
    background-position: right 10px center;
}

/* Remove default arrow in Firefox */
select::-ms-expand {
    display: none;
}
    </style>
</head>
<body>

<?php include('header.php'); ?>

<?php
include_once('controller/connect.php');

$dbs = new database();
$db = $dbs->connection();

// Assuming you have a function to fetch employees and projects from the database
$allemployees = fetchAllEmployees($db);
$projects = fetchProjects($db);
?>
<div class="validation-system">    
    <div class="validation-form">
        <div class="w3l-table-info">
            <h2>Assign Project to Employee</h2>

            <?php
            // Check if success or error message is present in the URL
            if (isset($_GET['success'])) {
                echo '<div class="alert success">' . $_GET['success'] . '</div>';
            } elseif (isset($_GET['error'])) {
                echo '<div class="alert error">' . $_GET['error'] . '</div>';
            }
            ?>

             <form method="POST" action="controller/assign_project.php">
                <label for="employee">Select Employee:</label>
                <select name="employee" id="employee" required>
                    <option selected disabled>Select Employee</option>
                    <?php foreach ($allemployees as $allemployee) : ?>
                        <option value="<?php echo $allemployee['EmployeeId']; ?>">
                            <?php echo $allemployee['FirstName'] . ' ' . $allemployee['LastName'].'-->'.$allemployee['EmployeeId']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <br>
                <label for="project">Select Project:</label>
                <select name="project" id="project" required>
                    <option selected disabled >Select Project</option>
                    <?php foreach ($projects as $project) : ?>
                        <option value="<?php echo $project['project_id']; ?>">
                            <?php echo $project['project_name']; ?>
                        </option>
                    <?php endforeach; ?>
                </select><br>
                
                <input type="submit" name="assign_project" value="Assign Project">
            </form>
        </div>
    </div>
</div>
</body>
</html>


<?php include('footer.php'); ?>