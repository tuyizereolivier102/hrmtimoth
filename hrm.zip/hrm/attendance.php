<?php include('header.php'); ?>
<?php
  include_once('controller/connect.php');
  
  $dbs = new database();
  $db=$dbs->connection();
  $TotalEmp =mysqli_query($db,"select count(EmployeeId) as emp from employee where RoleId !='1' ");
  $TotalEmploId = mysqli_fetch_assoc($TotalEmp);
  $pandingleave = mysqli_query($db,"select count(LeaveStatus) as pleave from leavedetails where LeaveStatus='Pending'");
  $tpandingleave = mysqli_fetch_assoc($pandingleave);
?>

<ol class="breadcrumb" style="margin: 10px 0px ! important;">
    <li class="breadcrumb-item" title="Home"><a style="color:blue" href="home.php">Attendance Reports</a></li>
</ol>
<div class="row" style="color: white; margin-right: 0; margin-left: 0;">
  <table id="table">
		<thead>
			<tr>
				<th style="text-transform: capitalize;">Profile Photo</th>
				<th style="text-transform: capitalize;">Name</th>
				<th style="text-transform: capitalize; text-align: center;">Employee Id</th>
				<th style="text-transform: capitalize; text-align: center;">Full Detail</th>
			</tr>
		</thead>
<!--four-grids here-->
		<div class="row" style="">
					

					<div class="clearfix"></div>
				</div>
<!--//four-grids here-->


  
<?php include('footer.php'); ?>

