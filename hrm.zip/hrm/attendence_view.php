<?php include('header.php'); ?>

<?php
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();

if (isset($_GET['dt'])) {
    $selectedDate = mysqli_real_escape_string($db, $_GET['dt']);

    // Fetch all employees for the selected date
    $attendanceQuery = mysqli_query($db, "SELECT a.*, CONCAT(e.FirstName, ' ', e.LastName) AS FullName 
                                          FROM attendance_records a
                                          JOIN employee e ON a.EmploiyeeId = e.EmployeeId
                                          WHERE a.regdate = '$selectedDate'");
}
?>

<ol class="breadcrumb" style="margin: 10px 0px !important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>View Attendance Date</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <h3>Attendance Details for <?php echo $selectedDate; ?></h3>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Employee ID</th>
                    <th>Employee Name</th>
                    <th>Attendance Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (isset($attendanceQuery)) {
                    $count = 1;
                    while ($row = mysqli_fetch_assoc($attendanceQuery)) :
                ?>
                        <tr>
                            <td><?php echo $count++; ?></td>
                            <td><?php echo $row['EmploiyeeId']; ?></td>
                            <td><?php echo $row['FullName']; ?></td>
                            <td><?php echo $row['attend']; ?></td>
                        </tr>
                <?php endwhile;
                } else {
                    echo '<tr><td colspan="4">No attendance records found for the selected date.</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php include('footer.php'); ?>
