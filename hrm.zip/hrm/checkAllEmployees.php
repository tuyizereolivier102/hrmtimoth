<?php
include_once('connect.php'); // Include your database connection file

// Fetch all employees from the database
$employeeQuery = mysqli_query($db, "SELECT * FROM employee");

if ($employeeQuery) {
    while ($employee = mysqli_fetch_assoc($employeeQuery)) {
        $empid = $employee['EmployeeId'];

        $loanQuery = mysqli_query($db, "SELECT SUM(loan_amount) as total_loans FROM loans WHERE EmployeeId = $empid");
        $paidLoanQuery = mysqli_query($db, "SELECT SUM(paid_amount) as total_paid FROM paid_loans WHERE EmployeeId = $empid");

        $loanResult = mysqli_fetch_assoc($loanQuery);
        $paidLoanResult = mysqli_fetch_assoc($paidLoanQuery);

        $totalLoans = $loanResult['total_loans'] ?? 0;
        $totalPaidLoans = $paidLoanResult['total_paid'] ?? 0;

        // Calculate the possible salary
        $possibleSalary = $employee['BasicSalary'] - $totalLoans + $totalPaidLoans;

        echo "<p><strong>Employee Name:</strong> {$employee['FirstName']} {$employee['LastName']}</p>";
        echo "<p><strong>Possible Salary:</strong> $possibleSalary</p>";
        echo "<hr>";
    }
} else {
    echo "Error fetching employees!";
}
?>
