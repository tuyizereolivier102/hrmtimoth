<?php include('header.php'); ?>

<?php 
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();
?>

<style>
#results {
    margin-top: 20px;
    padding: 15px;
    border: 1px solid #ddd;
    border-radius: 5px;
    background-color: #f8f8f8;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

#results p {
    margin: 0;
    padding-bottom: 10px;
}

#results strong {
    font-weight: bold;
}
</style>

<ol class="breadcrumb" style="margin: 10px 0px ! important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Loan Salary</li>
</ol>

<!--grid-->
<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <form method="POST" action="controller/checksalary.php" enctype="multipart/form-data" id="checkLoanForm">

            <!-- Employee ID -->
            <div class="col-md-4 control-label">
                <label class="control-label">Employee</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-user" aria-hidden="true"></i>
                    </span>
                    <select name="empid" title="Employee" class="form-control" required>
                        <option value="">-- Select Employee --</option>
                        <?php
                        $employeeQuery = mysqli_query($db, "SELECT EmployeeId, CONCAT(FirstName, ' ', LastName) AS FullName FROM employee");
                        while ($row = mysqli_fetch_assoc($employeeQuery)) {
                            echo "<option value='{$row['EmployeeId']}'>{$row['FullName']}-->{$row['EmployeeId']}</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <!-- Other form fields -->

            <div class="col-md-12 form-group">
                <button type="submit" name="submit1" class="btn btn-primary">Check Possible Salary</button>
                <button type="reset" class="btn btn-default">Reset</button>
            </div>
            <div class="clearfix"> </div>
        </form>
    </div>
</div>

<!-- Results Display -->
<div id="results"></div>
<?php include('footer.php'); ?>

<!-- AJAX Script -->
<script>
    document.getElementById('checkLoanForm').addEventListener('submit', function (event) {
        event.preventDefault();

        // Fetch and display results using AJAX
        var formData = new FormData(this);
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'controller/checksalary.php', true);
        xhr.onload = function () {
            if (xhr.status === 200) {
                document.getElementById('results').innerHTML = xhr.responseText;
            }
        };
        xhr.send(formData);
    });
</script>
<!-- AJAX Script for All Employees -->
<script>
    function printAllEmployees() {
        // Fetch and display results using AJAX for all employees
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'controller/printAllEmployees.php', true);
        xhr.onload = function () {
            if (xhr.status === 200) {
                document.getElementById('allEmployeesResults').innerHTML = xhr.responseText;
            }
        };
        xhr.send();
    }
</script>
<script>
    function printResults() {
        // Hide all buttons before printing
        var buttons = document.querySelectorAll('button');
        buttons.forEach(function (button) {
            button.style.display = 'none';
        });

        var printContent = document.getElementById('results').innerHTML;
        var printWindow = window.open('', '_blank');
        printWindow.document.write('<html><head><title>Results</title></head><body>');

        // Add company name, logo, and heading
        printWindow.document.write('<div style="text-align: center; margin-bottom: 20px;">');
        printWindow.document.write('<img src="images/unilak.jpg" alt="Company Logo" style="max-width: 100px; max-height: 100px;">');
       
        printWindow.document.write('<h1>University of Lay Adventist of Kigali (UNILAK)</h1>');
        printWindow.document.write('<h2>Customized Report</h2>');
        printWindow.document.write('</div>');

        printWindow.document.write('<table border="1" style="width:100%; border-collapse: collapse;">');
        printWindow.document.write(printContent);
        printWindow.document.write('</table></body></html>');
        printWindow.document.close();
        printWindow.print();
        
        // Show the buttons again after printing
        buttons.forEach(function (button) {
            button.style.display = 'block';
        });
    }
    function printAllEmployees() {
        // You can modify this function to fetch data for all employees and format it accordingly
        // For now, it opens a new window with a placeholder message
        var printWindow = window.open('', '_blank');
        printWindow.document.write('<html><head><title>All Employees</title></head><body>');

        // Add company name, logo, and heading
        printWindow.document.write('<div style="text-align: center; margin-bottom: 20px;">');
        printWindow.document.write('<img src="images/unilak.jpg" alt="Company Logo" style="max-width: 100px; max-height: 100px;">');
        printWindow.document.write('<h1>University of Lay Adventist of Kigali (UNILAK)</h1>');
        printWindow.document.write('<h2>Detail Report</h2>');
        printWindow.document.write('</div>');

        printWindow.document.write('<p>This is a placeholder message. Modify the printAllEmployees function to fetch and format data for all employees.</p>');
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
    }
</script>
