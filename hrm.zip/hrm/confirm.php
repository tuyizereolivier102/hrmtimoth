<?php
$dbase=mysqli_connect('localhost','root','','hrm_db');
$lid=$_GET['loan_id'];;;;
?>