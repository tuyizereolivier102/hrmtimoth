<?php
include_once('connect.php');
$dbs = new database();
$db = $dbs->connection();

if (isset($_POST['submit'])) {
 $loanId = mysqli_real_escape_string($db, $_POST['loan_id']);

    // Check if the loan exists and is pending
    $loanQuery = mysqli_query($db, "SELECT * FROM loans WHERE loan_id = '$loanId' AND LoanStatus = 'Pending'");
    $loanExists = mysqli_num_rows($loanQuery) > 0;

    if ($loanExists) {
        // Update the loan status to 'Approved'
        $updateQuery = mysqli_query($db, "UPDATE loans SET LoanStatus = 'Approved' WHERE loan_id = '$loanId'");

        if ($updateQuery) {
            echo "<script>window.alert('Loan approved successfully.'); window.location='../employee-loans.php';</script>";
            exit();
        } else {
            echo "<script>window.alert('Error updating loan status: " . mysqli_error($db) . "'); window.location='../employee-loans.php';</script>";
        }
    } else {
        echo "<script>window.alert('Loan not found or already approved.'); window.location='../employee-loans.php';</script>";
    }
}
if (isset($_POST['submit1'])) {
 $loanId = mysqli_real_escape_string($db, $_POST['loan_id']);

    // Check if the loan exists and is pending
    $loanQuery = mysqli_query($db, "SELECT * FROM loans WHERE loan_id = '$loanId' AND LoanStatus = 'Pending'");
    $loanExists = mysqli_num_rows($loanQuery) > 0;

    if ($loanExists) {
        // Update the loan status to 'Approved'
        $updateQuery = mysqli_query($db, "UPDATE loans SET LoanStatus = 'Closed' WHERE loan_id = '$loanId'");

        if ($updateQuery) {
            echo "<script>window.alert('Loan approved successfully.'); window.location='../employee-loans.php';</script>";
            exit();
        } else {
            echo "<script>window.alert('Error updating loan status: " . mysqli_error($db) . "'); window.location='../employee-loans.php';</script>";
        }
    } else {
        echo "<script>window.alert('Loan not found or already approved.'); window.location='../employee-loans.php';</script>";
    }
}
if (isset($_POST['delete'])) {
    $loanId = mysqli_real_escape_string($db, $_POST['loan_id']);

    // Check if the loan exists
    $loanQuery = mysqli_query($db, "SELECT * FROM loans WHERE loan_id = '$loanId'");
    $loanExists = mysqli_num_rows($loanQuery) > 0;

    if ($loanExists) {
        // Delete the loan
        $deleteQuery = mysqli_query($db, "DELETE FROM loans WHERE loan_id = '$loanId'");

        if ($deleteQuery) {
            echo "<script>window.alert('Loan deleted successfully.'); window.location='../employee-loans.php';</script>";
            exit();
        } else {
            echo "<script>window.alert('Error deleting loan: " . mysqli_error($db) . "'); window.location='../employee-loans.php';</script>";
        }
    } else {
        echo "<script>window.alert('Loan not found.'); window.location='../employee-loans.php';</script>";
    }
}
?>
