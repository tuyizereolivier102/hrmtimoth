<?php
// assign_project.php

include_once('connect.php');
$dbs = new database();
$db = $dbs->connection();

if (isset($_POST['assign_project'])) {
    $employeeId = $_POST['employee'];
    $projectId = $_POST['project'];
 
    // Check if the employee is already assigned to the project
    $checkAssignment = mysqli_query($db, "SELECT * FROM assign_project WHERE employee_id = '$employeeId' AND project_id = '$projectId'");
    
    if (mysqli_num_rows($checkAssignment) > 0) {
        // Employee is already assigned to the project
        header("location: ../assignproject.php?error=Employee is already assigned to the chosen project");
        exit;
    }

    // If not assigned, proceed with the assignment
    $assignmentDate = date("Y-m-d");
    $status = "Incomplete";
    $assignedBy = 'admin'; // Change this to the actual session value
    
    mysqli_query($db, "INSERT INTO assign_project (employee_id, project_id, assignment_date, status, assignedby) 
                       VALUES ('$employeeId', '$projectId', '$assignmentDate', '$status', '$assignedBy')");

    header("location: ../assignproject.php?success=Project assigned successfully");
    exit;
}
?>
