<?php
include_once('connect.php');
$dbs = new database();
$db = $dbs->connection();

if (isset($_POST['submit1'])) {
    $empid = mysqli_real_escape_string($db, $_POST['empid']);

    // Check if the employee has an approved loan
    $approvedLoanQuery = mysqli_query($db, "SELECT * FROM loans WHERE EmployeeId = '$empid' AND LoanStatus = 'Approved'");
    $hasApprovedLoan = mysqli_num_rows($approvedLoanQuery) > 0;

    if ($hasApprovedLoan) {
        // Fetch the loan amount
        $loanAmountQuery = mysqli_query($db, "SELECT SUM(amount) AS totalLoan FROM loans WHERE EmployeeId = '$empid' AND LoanStatus = 'Approved'");
        $loanRow = mysqli_fetch_assoc($loanAmountQuery);
        $loanAmount = $loanRow['totalLoan'];

        // Fetch the current salary_amount from the employee table
        $currentSalaryQuery = mysqli_query($db, "SELECT e.salary_amount AS empsalary, r.Salary_amount AS roleSalary
                                                 FROM employee e
                                                 JOIN role r ON e.RoleId = r.RoleId
                                                 WHERE e.EmployeeId = '$empid'");
        $currentSalaryRow = mysqli_fetch_assoc($currentSalaryQuery);
        $roleSalary = $currentSalaryRow['empsalary'];

        // Calculate the new salary (subtract loan amount)
        $newSalary = max(0, $roleSalary - $loanAmount);

        // Calculate salary based on attendance (replace 'tbl_attendance' with your actual table name)
        $attendanceQuery = mysqli_query($db, "SELECT attend FROM attendance_records WHERE EmploiyeeId = '$empid'");
        $totalDays = mysqli_num_rows($attendanceQuery);

        // Assuming 'present' in 'attend' column indicates present and others indicate absent
        $presentDays = mysqli_num_rows(mysqli_query($db, "SELECT attend FROM attendance_records WHERE EmploiyeeId = '$empid' AND attend = 'present'"));
        $absentDays = $totalDays - $presentDays;

        // Adjust salary based on present and absent days
        $dailySalary = $roleSalary / 30; // Assuming monthly salary is distributed evenly for each day
        $presentSalary = $presentDays * $dailySalary;
        $absentDeduction = $absentDays * $dailySalary;
        $finalSalary = max(0, $newSalary - $absentDeduction);

        // Update the salary_amount in the employee table
        mysqli_query($db, "UPDATE employee SET salary_amount = '$finalSalary' WHERE EmployeeId = '$empid'");

        // Redirect to detailview.php with the updated EmployeeId
        echo "<script>window.alert('Loan clearance successful. Employee\'s new salary: $finalSalary'); window.location='../employeeview.php';</script>";
        exit(); // Ensure that no further code is executed after the header redirect
    } else {
        echo "<script>window.alert('No approved loan found for the employee. No changes made to the salary.'); window.location='../clearingsalary.php';</script>";
    }
}
?>
