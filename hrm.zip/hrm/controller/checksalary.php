<?php
include_once('connect.php');
$dbs = new database();
$db = $dbs->connection();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the selected employee ID
    $employeeId = mysqli_real_escape_string($db, $_POST['empid']);

    // Fetch employee details from the database based on the employee ID
    $employeeQuery = mysqli_query($db, "SELECT * FROM employee WHERE EmployeeId = '$employeeId'");
    $employee = mysqli_fetch_assoc($employeeQuery);

    // Check if the employee exists
    if (!$employee) {
        echo "Employee not found.";
        exit(); // Stop further execution if employee not found
    }

    // Fetch employee loans from the 'loans' table
    $loansQuery = mysqli_query($db, "SELECT SUM(amount) as totalLoans FROM loans WHERE EmployeeId = '$employeeId'");
    $loans = mysqli_fetch_assoc($loansQuery);

    // Fetch employee paid loans from the 'paid_loan' table
    $paidLoansQuery = mysqli_query($db, "SELECT SUM(pl.amount_paid) as totalPaidLoans 
                                          FROM paid_loan pl
                                          JOIN loans l ON pl.loan_id = l.loan_id
                                          WHERE l.EmployeeId = '$employeeId'");
    $paidLoans = mysqli_fetch_assoc($paidLoansQuery);

    // Fetch total attendance days, present days, and absent days for the selected employee
    $attendanceQuery = mysqli_query($db, "SELECT COUNT(*) as totalAttendance, 
                                                 SUM(CASE WHEN attend = 'Present' THEN 1 ELSE 0 END) as presentDays,
                                                 SUM(CASE WHEN attend = 'Absent' THEN 1 ELSE 0 END) as absentDays
                                          FROM attendance_records 
                                          WHERE EmploiyeeId = '$employeeId'");
    $attendance = mysqli_fetch_assoc($attendanceQuery);

    // Fetch overtime details for the selected employee
    $overtimeQuery = mysqli_query($db, "SELECT SUM(overtime_hours) as totalOvertimeHours
                                         FROM overtime
                                         WHERE EmploiyeeId = '$employeeId'");
    $overtime = mysqli_fetch_assoc($overtimeQuery);

    // Calculate remaining loan
    $remainingLoan = max(0, $loans['totalLoans'] - $paidLoans['totalPaidLoans']);

    // Calculate the daily salary
    $dailySalary = $employee['Salary_amount'] / 30; // Assuming 30 days in a month
    $msalary = $employee['Salary_amount'];

    // Calculate the overtime amount (example calculation)
    $overtimeAmount = calculateOvertimeAmount($employeeId, $db);

    // Calculate the possible salary
    $possibleSalary = $dailySalary * $attendance['totalAttendance'] + $overtimeAmount - $remainingLoan;

    // Display the result
    echo "<p><strong>Employee Names:</strong> {$employee['FirstName']} {$employee['LastName']}</p>";
    echo "<p><strong>Current Salary (Per Day):</strong> $dailySalary</p>";
    echo "<p><strong>Current Salary (Per Month):</strong> $msalary</p>";
    echo "<p><strong>Total Working Days:</strong> {$attendance['totalAttendance']}</p>";
    echo "<p><strong>Present Days:</strong> {$attendance['presentDays']}</p>";
    echo "<p><strong>Absent Days:</strong> {$attendance['absentDays']}</p>";
    echo "<p><strong>Remaining Loan:</strong> $remainingLoan</p>";
    echo "<p><strong>Month Salary after all activities:</strong> $possibleSalary</p>";

    // Display overtime details
    if ($overtime['totalOvertimeHours'] > 0) {
        $overtimeHours = floor($overtime['totalOvertimeHours']);
        $overtimeMinutes = ($overtime['totalOvertimeHours'] - $overtimeHours) * 60;
        echo "<p><strong>Overtime Hours:</strong> $overtimeHours Hours</p>";
        echo "<p><strong>Overtime Minutes:</strong> $overtimeMinutes Minutes</p>";
    } else {
        echo "<p><strong>No Overtime recorded.</strong></p>";
    }

    echo "<hr>";

    // Check if the form for updating salary and loans has been submitted
    if (isset($_POST['updateSalaryLoans'])) {
        include_once('update_salary_loans.php');
    } else {
        // Display buttons for printing the results

        echo "<form method='POST' action='controller/checksalary.php'>";
        echo "<input type='hidden' name='empid' value='$employeeId'>";
        echo "<button type='submit' name='updateSalaryLoans' class='btn btn-primary'>Update Salary and Loans Paid</button>";
        echo "<button type='button' onclick='printResults()' class='btn btn-success'>Print Results</button>";
        echo "<button type='button' onclick='printAllEmployees()' class='btn btn-info'>Print All Employees</button>";
        echo "</form>";
      
        
    }
} else {
    // If the form is not submitted, handle the case accordingly
    echo "Form not submitted";
}
//<button type="button" onclick="printResults()">Print Results</button>
//<button type="button" onclick="printAllEmployees()">Print All Employees</button>
// Function to calculate overtime amount (adjust based on your logic)
function calculateOvertimeAmount($employeeId, $db) {
    $overtimeQuery = mysqli_query($db, "SELECT SUM(overtime_hours) as totalOvertimeHours
                                         FROM overtime
                                         WHERE EmploiyeeId = '$employeeId'");
    $overtime = mysqli_fetch_assoc($overtimeQuery);

    // Example calculation: Assume overtime pay rate is $10 per hour
    $overtimePayRate = 10;
    $overtimeAmount = $overtime['totalOvertimeHours'] * $overtimePayRate;

    return $overtimeAmount;
}

?>
<script>
    function printResults() {
        window.print();
    }
</script>
