<?php
	
	class database
	{
		
		function connection()
		{
			return mysqli_connect('localhost','root','','hrm_db');
		}
	}
// In your controller/connect.php file or another file where you handle database interactions


function fetchEmployees($db) {
    $result = mysqli_query($db, "SELECT * FROM employee");
    $employees = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $employees[] = $row;
    }

    return $employees;
}
function fetchAllEmployees($db) {
    $result = mysqli_query($db, "select * from employee where RoleId !='1'");
    
    if (!$result) {
        // Handle the error, for example, log it or return an empty array
        error_log("Error: " . mysqli_error($db));
        return array();
    }

    $allemployees = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $allemployees[] = $row;
    }

    return $allemployees;
}

function fetchProjects($db) {
    $result = mysqli_query($db, "SELECT * FROM project");
    $projects = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $projects[] = $row;
    }

    return $projects;
}
function fetchAssignedProjects($db) {
    $result = mysqli_query($db, "SELECT ap.*, e.FirstName AS employee_name,e.EmployeeId AS empid, p.project_name FROM assign_project ap
                                  JOIN employee e ON ap.employee_id = e.EmployeeId
                                  JOIN project p ON ap.project_id = p.project_id");
     if (!empty($searchKeyword)) {
        $searchKeyword = mysqli_real_escape_string($db, $searchKeyword);
        $query .= " WHERE 
                    e.employee_name LIKE '%$searchKeyword%' OR
                    e.empid LIKE '%$searchKeyword%' OR
                    p.project_name LIKE '%$searchKeyword%' OR
                    ap.assignment_date LIKE '%$searchKeyword%' OR
                    ap.status LIKE '%$searchKeyword%' OR
                    ap.assignedby LIKE '%$searchKeyword%'";
    }

    $assignedProjects = array();

    while ($row = mysqli_fetch_assoc($result)) {
        $assignedProjects[] = $row;
    }

    return $assignedProjects;
}

?>
