<?php

// Database credentials (replace with your actual values)
$hostname = "localhost";  // Replace with your database hostname
$username = "root";  // Replace with your database username
$password = "";  // Replace with your database password
$databaseName = "hrm_db";  // Replace with your database name

// Error handling
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Establish the connection
$db = new mysqli($hostname, $username, $password, $databaseName);

// Check for connection errors
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Optional: Set the character set for better compatibility
$db->set_charset("utf8mb4");
?>
