<?php

include_once('connect.php'); // Adjust the path as needed

$dbs = new database();
$db = $dbs->connection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $mode = $_POST['mode'];
    $announcementId = isset($_POST['editAnnouncementId']) ? $_POST['editAnnouncementId'] : null;
    $title = $_POST['title'];
    $content = $_POST['content'];
    $expirationDate = isset($_POST['expirationDate']) ? $_POST['expirationDate'] : null;

    // Sanitize data to prevent SQL injection
    $title = mysqli_real_escape_string($db, $title);
    $content = mysqli_real_escape_string($db, $content);

    // Check if it's an edit mode
    if ($mode === 'edit' && !empty($announcementId)) {
        // Update the existing announcement
        $updateQuery = "UPDATE announcements SET title='$title', content='$content', expiration_date='$expirationDate' WHERE announcement_id=$announcementId";
        mysqli_query($db, $updateQuery);
    } else {
        // Create a new announcement
        $insertQuery = "INSERT INTO announcements (title, content, expiration_date) VALUES ('$title', '$content', '$expirationDate')";
        mysqli_query($db, $insertQuery);
    }

    // Redirect to the home page or display a success message
    header("Location: ../announcement.php");
    exit();
} else {
    // Redirect to the home page or display an error message for invalid access
    header("Location: ../announcement.php");
    exit();
}
