<?php
include_once('connect.php');
  
$dbs = new database();
$db = $dbs->connection();

if (isset($_GET['announcement_id'])) {
    $announcementId = $_GET['announcement_id'];

    // Perform deletion
    $deleteQuery = "DELETE FROM announcements WHERE announcement_id = '$announcementId'";
    if ($db->query($deleteQuery)) {
        // Successfully deleted
        header("Location: ../announcement.php");
        exit();
    } else {
        // Error in deletion
        echo "Error deleting announcement: " . $db->error;
    }
} else {
    // No announcementId provided
    echo "Invalid request";
}
?>
