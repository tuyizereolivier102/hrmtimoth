<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Page Title</title>
    <link rel="stylesheet" href="css/css/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            background-color: #f3f3f3;
        }

        .left-sidebar {
            width: 250px;
            min-height: 100vh;
            background-color: #333;
            color: #fff;
            position: fixed;
            top: 0;
            left: 0;
            overflow-y: auto;
            transition: width 0.3s;
        }

        .scroll-sidebar {
            padding: 15px;
        }

        .sidebar-nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-nav li {
            margin-bottom: 10px;
        }

        .sidebar-nav a {
            text-decoration: none;
            color: #fff;
            display: block;
            padding: 10px;
            transition: background-color 0.3s;
            border-radius: 5px;
            position: relative;
        }

        .sidebar-nav a:hover {
            background-color: #555;
        }

        .has-arrow:after {
            content: '\25BC'; /* Downward-pointing triangle */
            font-size: 12px;
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            transition: transform 0.3s;
        }

        .has-arrow.collapsed:after {
            transform: translateY(-50%) rotate(-90deg);
        }

        .collapse {
            display: none;
            padding-left: 20px;
        }

        .nav-label {
            font-weight: bold;
            font-size: 16px;
            margin-bottom: 15px;
            display: block;
        }

        /* Add styles for the page content */
        .page-content {
            margin-left: 250px; /* Adjust this value based on your sidebar width */
            padding: 20px;
        }
    </style>
</head>
<body>

<div class="left-sidebar">
    <div class="scroll-sidebar">
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="nav-label">Home</li>
                <li><a href="constant/logout.php" style="color: red;"><i class="far fa-angry"></i>Logout</a></li>
                <li><a href="dashboard.php" aria-expanded="false"><i class="fa fa-tachometer"></i>Dashboard</a></li>
                <li class="has-arrow">
                    <a href="#" aria-expanded="false"><i class="fa fa-user"></i><span class="hide-menu">Consumer</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="add_client.php">Add Consumer</a></li>
                        <li><a href="client.php">Manage Consumer</a></li>
                    </ul>
                </li>
                <li class="has-arrow">
                    <a href="#" aria-expanded="false"><i class="fa fa-users"></i><span class="hide-menu">Supplier</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="add-brand.php">Add Supplier</a></li>
                        <li><a href="brand.php">Manage Supplier</a></li>
                    </ul>
                </li>
                <li class="has-arrow">
                    <a href="#" aria-expanded="false"><i class="fa fa-list"></i><span class="hide-menu">Categories</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="add-category.php">Add Category</a></li>
                        <li><a href="categories.php">Manage Categories</a></li>
                    </ul>
                </li>
                <li class="has-arrow">
                    <a href="#" aria-expanded="false"><i class="mdi-gas-cylinder mdi"></i><span class="hide-menu">Cylinder</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="add-product.php">Add Cylinder</a></li>
                        <li><a href="product.php">Manage Cylinders</a></li>
                    </ul>
                </li>
                <li class="has-arrow">
                    <a href="#" aria-expanded="false"><i class="mdi mdi-arrow-compress-all"></i><span class="hide-menu">Connections</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="new_connection.php">New Connections </a></li>
                        <li><a href="onhold_connection.php">On Hold Connections </a></li>
                        <li><a href="approved_connection.php">Approved Connections </a></li>
                        <li><a href="rejected_connection.php">Rejected Connections </a></li>
                    </ul>
                </li>
                <li class="has-arrow">
                    <a href="#" aria-expanded="false"><i class="fa fa-shopping-cart"></i><span class="hide-menu">Booking</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="add-order.php">Add Booking</a></li>
                        <li><a href="Order.php">Manage Booking</a></li>
                    </ul>
                </li>
                <li><a href="report.php" href="#" aria-expanded="false"><i class="fa fa-file"></i><span class="hide-menu">Reports</span></a></li>
                <li class="has-arrow">
                    <a href="#" aria-expanded="false"><i class="fa fa-cog"></i><span class="hide-menu">Setting</span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="manage_website.php">Appearance Management</a></li>
                        <li><a href="setting.php">Change Profile</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</div>

<div class="page-content">
    <!-- Your page content goes here -->
    <h1>Welcome to Your Dashboard</h1>
    <p>This is your main content area. You can add your content here.</p>
</div>

</body>
</html>
