<?php
// fetchEmployeeDetails.php

// Include database connection
include_once('connect.php');

// Check if empid is set in the GET request
if (isset($_GET['empid'])) {
    $employeeId = $_GET['empid'];

    // Create a database instance
    $dbs = new database();
    $db = $dbs->connection();

    // Prepare and execute a query to fetch employee details
    $query = "SELECT * FROM employee WHERE EmployeeId = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param("i", $employeeId);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the query was successful
    if ($result) {
        // Fetch the employee details
        $employeeDetails = $result->fetch_assoc();

        // Return the details as JSON
        header('Content-Type: application/json');
        echo json_encode($employeeDetails);
    } else {
        // Return an error message
        echo "Error fetching employee details";
    }

    // Close the database connection
    $stmt->close();
    $db->close();
} else {
    // Return an error message if empid is not set
    echo "Employee ID not provided";
}
?>
