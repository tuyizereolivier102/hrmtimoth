<?php
include_once('../controller/connect.php');
$dbs = new database();
$db = $dbs->connection();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $empid = mysqli_real_escape_string($db, $_POST['empid']);

    // Fetch loan amount and loan ID for the selected employee
    $loanQuery = mysqli_query($db, "SELECT amount, loan_id FROM loans WHERE EmployeeId = '$empid' AND LoanStatus = 'Approved'");
    
    if (mysqli_num_rows($loanQuery) > 0) {
        // Fetch the loan amount and loan ID
        $row = mysqli_fetch_assoc($loanQuery);
        $loanAmount = $row['amount'];
        $loanid = $row['loan_id'];

        // Return a JSON response
        echo json_encode(['loanAmount' => $loanAmount, 'loanId' => $loanid]);
    } else {
        // No approved loans found for the selected employee
        echo json_encode(['loanAmount' => 0, 'loanId' => null]);
    }
} else {
    // Invalid request method
    echo json_encode(['error' => 'Invalid request method']);
}
?>
