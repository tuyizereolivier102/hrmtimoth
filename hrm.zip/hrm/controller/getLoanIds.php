<?php
include_once('connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming you have sanitized the input to prevent SQL injection
    $empid = $_POST['empid'];

    // Instantiate the database connection
    $dbs = new database();
    $db = $dbs->connection();

    // Fetch total loan amount for the selected employee
    $query = "SELECT SUM(amount) AS totalLoanAmount FROM loans WHERE EmployeeId = '$empid'";
    $result = mysqli_query($db, $query);

    if ($result) {
        $row = mysqli_fetch_assoc($result);

        // Return the result in JSON format
        echo json_encode(['totalLoanAmount' => $row['totalLoanAmount']]);
    } else {
        // Handle the error case
        echo json_encode(['totalLoanAmount' => null]);
    }

    // Close the database connection
    mysqli_close($db);
} else {
    // Handle the case where the request method is not POST
    echo json_encode(['totalLoanAmount' => null]);
}
?>
