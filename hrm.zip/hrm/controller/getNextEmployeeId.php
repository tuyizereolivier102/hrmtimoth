<?php
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();

// Fetch the maximum EmployeeId from the database
$result = mysqli_query($db, "SELECT MAX(EmployeeId) as maxId FROM employee");
$row = mysqli_fetch_assoc($result);

// Calculate the next available EmployeeId
$nextEmployeeId = $row['maxId'] + 1;

// Return the next available EmployeeId
echo $nextEmployeeId;
?>
