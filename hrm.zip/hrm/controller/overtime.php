
<?php
include_once('connect.php');
$dbs = new database();
$db = $dbs->connection();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $employeeId = $_POST['empid'];
    $startTime = $_POST['startTime'];
    $endTime = $_POST['endTime'];
    $overtimeReason = $_POST['overtimeReason'];

    // Calculate overtime hours
    $startTimestamp = strtotime($startTime);
    $endTimestamp = strtotime($endTime);
    $overtimeHours = round(($endTimestamp - $startTimestamp) / 3600, 2);

    // Insert data into the overtime table
    $insertQuery = "INSERT INTO overtime (EmploiyeeId, start_time, end_time, overtime_hours, overtime_reason)
                    VALUES ('$employeeId', '$startTime', '$endTime', '$overtimeHours', '$overtimeReason')";

    if (mysqli_query($db, $insertQuery)) {
        echo "<script>window.alert('Overtime submitted successfully!'); window.location='../viewovertime.php';</script>";
        // Redirect to another page after successful submission
        //header("Location: ../admin/viewovertime.php");
        exit();
    } else {
        echo "<p><strong>Error:</strong> " . mysqli_error($db) . "</p>";
    }
}
?>