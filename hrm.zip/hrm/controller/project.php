<?php
include_once('connect.php');
$dbs = new database();
$db = $dbs->connection();
session_start();

if (isset($_POST['submit'])) {
    $data = $_POST;
    $editid = 0;

    if (isset($_GET['projedit']) && $_GET['projedit'] > 0) {
        $editid = $_GET['projedit'];
    }

    $projectName = $data['project_name'];
    $description = $data['description'];
    $startDate = $data['start_date'];
    $endDate = $data['end_date'];

    // Add your logic to generate or fetch the project ID
    $projectId = ""; 

    // Assuming you have a function to handle file uploads securely
    $uploadedFile = handleFileUpload($_FILES['project_file'], 'project_file');

    // Get the current time
    $createdAt = date("Y-m-d H:i:s");

    $status = "Incomplete"; // Set the default status

    $result = ""; // Variable to store success or error message

    if ($editid == 0) {
        // Perform insert operation
        mysqli_query($db, "INSERT INTO project (project_id, project_name, description, start_date, end_date, project_file, created_at, status) 
                          VALUES ('', '$projectName', '$description', '$startDate', '$endDate', '$uploadedFile', '$createdAt', '$status')");

        $result = "Project added successfully!";
          header("location:../projectview.php");
                exit;
    } else {
        // Perform update operation
        mysqli_query($db, "UPDATE project SET project_name='$projectName', description='$description', 
                          start_date='$startDate', end_date='$endDate', project_file='$uploadedFile', status='$status' 
                          WHERE project_id='$editid'");

        $result = "Project updated successfully!";
          header("location:../projectview.php");
                exit;
    }

    header("location:../project.php?msg=$result");
    exit;
}

// Function to handle file upload securely and only allow PDF files
function handleFileUpload($file, $uploadDir)
{
    // Ensure that the target directory exists
    $targetDir = "../$uploadDir/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    // Check if the uploaded file is a PDF
    $allowedFileType = ['application/pdf'];
    if (in_array($file['type'], $allowedFileType)) {
        // Generate a unique filename to prevent overwriting
        $uniqueFileName = uniqid() . '_' . basename($file['name']);
        $targetFile = $targetDir . $uniqueFileName;

        // Move uploaded file to the specified directory
        move_uploaded_file($file['tmp_name'], $targetFile);

        return $uniqueFileName; // Return the unique filename as needed
    } else {
        header("location:../project.php?msg=Invalid PDF file! Please select a valid PDF file.");
        exit;
    }
}
?>
