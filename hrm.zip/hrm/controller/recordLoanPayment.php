<?php
error_reporting(0);
include_once('connect.php');
$dbs = new database();
$db = $dbs->connection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $empid = mysqli_real_escape_string($db, $_POST['empid']);
    $loanId = mysqli_real_escape_string($db, $_POST['loanid']);
    $paymentAmount = mysqli_real_escape_string($db, $_POST['payment_amount']);
    $paymentDate = mysqli_real_escape_string($db, $_POST['payment_date']);

    // Check if the remaining amount after the payment is zero
    $checkZeroAmountQuery = mysqli_query($db, "SELECT amount FROM loans WHERE EmployeeId = '$empid' AND LoanStatus = 'Approved'");
    $row = mysqli_fetch_assoc($checkZeroAmountQuery);
    $remainingAmount = $row['amount'];

    // Insert the loan payment record into the database
    $insertPaymentQuery = mysqli_query($db, "INSERT INTO paid_loan(loan_id, payment_date, amount_paid) VALUES ('$loanId','$paymentDate','$paymentAmount')");

    if ($insertPaymentQuery) {
        // Update the loan status to 'Paid' in the loans table
       // mysqli_query($db, "UPDATE loans SET LoanStatus = 'Approved', amount = amount - '$paymentAmount' WHERE loan_id = '$loanId'");

        echo "<script>window.alert('Loan payment recorded successfully.'); window.location='../home.php';</script>";
    } else {
        echo "<script>window.alert('Error recording loan payment. Please try again.'); window.location='../home.php';</script>";
    }
} else {
    // Invalid request method
    echo "Invalid request method";
}
?>
