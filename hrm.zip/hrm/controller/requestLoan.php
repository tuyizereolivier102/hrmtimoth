<?php
include_once('connect.php');
$dbs = new database();
$db = $dbs->connection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $empid = mysqli_real_escape_string($db, $_POST['empid']);
    $loanAmount = mysqli_real_escape_string($db, $_POST['loanAmount']);
    $purpose = mysqli_real_escape_string($db, $_POST['purpose']);

    // Retrieve employee's salary
    $getSalaryQuery = mysqli_query($db, "SELECT Salary_amount FROM employee WHERE EmployeeId = '$empid'");
    $row = mysqli_fetch_assoc($getSalaryQuery);
    $salary = $row['Salary_amount'];

    // Calculate maximum loan amount (75% of salary)
    $maxLoanAmount = 0.75 * $salary;

    // Check if the requested loan amount is within the limit
    if ($loanAmount <= $maxLoanAmount) {
        // Insert the loan request into the loans table
        $insertLoanQuery = mysqli_query($db, "INSERT INTO loans (EmployeeId, amount, LoanStatus, purpose, request_date) VALUES ('$empid', '$loanAmount', 'Pending', '$purpose', NOW())");

        if ($insertLoanQuery) {
            echo "<script>window.alert('Loan request submitted successfully.'); window.location='../home.php';</script>";
        } else {
            echo "<script>window.alert('Error submitting loan request. Please try again.'); window.location='../home.php';</script>";
        }
    } else {
        // Display error message if the requested loan amount exceeds the limit
        echo "<script>window.alert('Error: Loan amount exceeds 75% of your salary. Please request a lower amount.'); window.location='../loan_request.php';</script>";
    }
} else {
    // Invalid request method
    echo "Invalid request method";
}
?>
