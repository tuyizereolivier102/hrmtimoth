<?php
// Include the database connection file
include_once('connect.php');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the employee ID
    $employeeId = mysqli_real_escape_string($db, $_POST['empid']);

    // Fetch the current salary of the selected employee
    $currentSalaryQuery = mysqli_query($db, "SELECT Salary_amount FROM employee WHERE EmployeeId = '$employeeId'");
    $currentSalaryResult = mysqli_fetch_assoc($currentSalaryQuery);

    if ($currentSalaryResult) {
        // Get the current salary
        $currentSalary = $currentSalaryResult['Salary_amount'];

        // Update salary to the current salary
        mysqli_query($db, "UPDATE employee SET Salary_amount = '$currentSalary' WHERE EmployeeId = '$employeeId'");

        // Example: Mark a randomly selected loan for the employee as paid
        $randomLoanQuery = mysqli_query($db, "SELECT loan_id, amount FROM loans WHERE EmployeeId = '$employeeId' ORDER BY RAND() LIMIT 1");
        $randomLoan = mysqli_fetch_assoc($randomLoanQuery);

        if ($randomLoan) {
            $loanId = $randomLoan['loan_id'];
            $amountPaid = $randomLoan['amount'];

            // Insert a record in the paid_loan table
            $paymentDate = date('Y-m-d'); // Use the current date as the payment date
            mysqli_query($db, "INSERT INTO paid_loan (loan_id, payment_date, amount_paid) VALUES ('$loanId', '$paymentDate', '$amountPaid')");

            echo "Salary updated to the current salary, and a random loan paid!";
        } else {
            echo "No loans found for the employee.";
        }
    } else {
        echo "Employee not found.";
    }
} else {
    // If the form is not submitted, handle the case accordingly
    echo "Form not submitted";
}
?>
