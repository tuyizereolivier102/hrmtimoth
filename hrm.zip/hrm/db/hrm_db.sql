-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 22, 2024 at 01:08 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hrm_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `announcement_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expiration_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`announcement_id`, `title`, `content`, `created_at`, `expiration_date`) VALUES
(6, 'gfhgfhfgh', 'fghfghfgh', '2024-01-19 18:44:04', '2024-01-26'),
(7, 'gfhfhgf', 'fghfghgf', '2024-01-19 18:44:12', '2024-02-01'),
(10, 'New', 'ICT is leveraged for economic, societal, and interpersonal transactions and interactions. ICT has drastically changed how ghhh', '2024-01-19 18:48:58', '2024-01-20');

-- --------------------------------------------------------

--
-- Table structure for table `assign_project`
--

CREATE TABLE `assign_project` (
  `assign_id` int(11) NOT NULL,
  `employee_id` varchar(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `assignment_date` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `assignedby` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assign_project`
--

INSERT INTO `assign_project` (`assign_id`, `employee_id`, `project_id`, `assignment_date`, `status`, `assignedby`) VALUES
(1, '1478963', 1, '2024-01-22', 'Complete', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_records`
--

CREATE TABLE `attendance_records` (
  `id` int(11) NOT NULL,
  `EmploiyeeId` varchar(11) NOT NULL,
  `attend` enum('present','absent') NOT NULL,
  `att_time` datetime DEFAULT current_timestamp(),
  `month` varchar(40) NOT NULL,
  `regdate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance_records`
--

INSERT INTO `attendance_records` (`id`, `EmploiyeeId`, `attend`, `att_time`, `month`, `regdate`) VALUES
(1, '2', 'present', '2024-01-11 15:07:12', '01', '2024-01-11'),
(2, '35678', 'absent', '2024-01-11 15:07:12', '01', '2024-01-11'),
(3, 'MD001', 'absent', '2024-01-11 15:07:12', '01', '2024-01-11'),
(4, 'MD002', 'present', '2024-01-11 15:07:12', '01', '2024-01-11'),
(5, '2', 'present', '2024-01-19 14:31:13', '01', '2024-01-19'),
(6, '35678', 'present', '2024-01-19 14:31:13', '01', '2024-01-19'),
(7, 'MD001', 'present', '2024-01-19 14:31:13', '01', '2024-01-19'),
(8, 'MD002', 'present', '2024-01-19 14:31:13', '01', '2024-01-19'),
(34, '0', 'present', '2024-01-19 20:04:18', '', '2024-01-19'),
(35, '0', 'present', '2024-01-19 20:04:22', '', '2024-01-19'),
(36, '0', 'present', '2024-01-19 20:04:24', '', '2024-01-19');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `CityId` int(11) NOT NULL,
  `StateId` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`CityId`, `StateId`, `Name`) VALUES
(1, 1, 'Sample 101'),
(2, 1, 'Sample 102'),
(21, 1, 'Manila'),
(22, 1, 'Muntinlupa'),
(23, 4, 'Los Angeles'),
(24, 3, 'Washington'),
(26, 7, 'Byahi'),
(27, 7, 'Umuganda'),
(28, 6, 'KIMISAGARA'),
(29, 1, 'KIMISAGARA');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `CountryId` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`CountryId`, `Name`) VALUES
(15, 'Rwanda'),
(16, 'Liberia');

-- --------------------------------------------------------

--
-- Table structure for table `dailyworkload`
--

CREATE TABLE `dailyworkload` (
  `DailyWorkLoadId` bigint(20) NOT NULL,
  `EmpId` varchar(50) NOT NULL,
  `LoginDate` datetime DEFAULT NULL,
  `LogoutDate` datetime DEFAULT NULL,
  `DailyWorkingminutes` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dailyworkload`
--

INSERT INTO `dailyworkload` (`DailyWorkLoadId`, `EmpId`, `LoginDate`, `LogoutDate`, `DailyWorkingminutes`) VALUES
(1, '35678', '2023-12-06 17:00:16', '2023-12-06 17:14:34', 14),
(2, '35678', '2023-12-07 08:49:13', NULL, NULL),
(3, '35678', '2023-12-20 13:21:12', NULL, NULL),
(4, '1478963', '2023-12-22 00:07:24', '2023-12-22 08:42:51', 515),
(5, '3567800000', '2023-12-22 03:18:50', '2023-12-22 07:32:02', 253),
(6, '35678', '2023-12-22 08:43:05', '2023-12-22 10:18:09', 28387008),
(7, '35678', '2024-01-06 22:52:05', NULL, NULL),
(8, '35678', '2024-01-07 16:39:18', '2024-01-07 19:14:52', 156),
(9, 'MD002', '2024-01-09 17:25:25', NULL, NULL),
(10, '35678', '2024-01-11 13:42:51', NULL, NULL),
(11, 'M003', '2024-01-19 19:46:34', '2024-01-19 20:04:55', 28427915),
(12, '35678', '2024-01-19 20:05:12', '2024-01-19 20:06:41', 28427917),
(13, 'MD002', '2024-01-19 20:07:55', '2024-01-19 20:11:11', 28427921),
(14, '002', '2024-01-21 12:24:19', NULL, NULL),
(15, '1478963', '2024-01-22 02:43:14', NULL, NULL),
(16, 'EM002', '2024-01-22 03:17:24', '2024-01-22 03:41:14', 24);

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `DepartmentId` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`DepartmentId`, `Name`) VALUES
(1, 'ACCOUNTING'),
(2, 'ICT');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `EmpId` bigint(20) NOT NULL,
  `EmployeeId` varchar(11) NOT NULL,
  `FirstName` varchar(200) NOT NULL,
  `MiddleName` varchar(200) NOT NULL,
  `LastName` varchar(200) NOT NULL,
  `Birthdate` date NOT NULL,
  `Gender` int(10) NOT NULL,
  `cvfile` varchar(500) NOT NULL,
  `contractfile` varchar(500) NOT NULL,
  `CityId` int(11) NOT NULL,
  `Mobile` decimal(10,0) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Password` varchar(25) NOT NULL,
  `AadharNumber` varchar(25) NOT NULL,
  `MaritalStatus` int(11) NOT NULL,
  `PositionId` int(11) NOT NULL,
  `DepartmentId` int(11) NOT NULL,
  `CreatedBy` bigint(20) NOT NULL,
  `CreatedDate` datetime NOT NULL,
  `ModifiedBy` bigint(20) DEFAULT NULL,
  `ModifiedDate` datetime DEFAULT NULL,
  `JoinDate` date NOT NULL,
  `LeaveDate` date DEFAULT NULL,
  `LastLogin` datetime DEFAULT NULL,
  `LastLogout` datetime DEFAULT NULL,
  `StatusId` int(11) NOT NULL,
  `RoleId` int(11) NOT NULL,
  `ImageName` varchar(1000) DEFAULT NULL,
  `Salary_amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`EmpId`, `EmployeeId`, `FirstName`, `MiddleName`, `LastName`, `Birthdate`, `Gender`, `cvfile`, `contractfile`, `CityId`, `Mobile`, `Email`, `Password`, `AadharNumber`, `MaritalStatus`, `PositionId`, `DepartmentId`, `CreatedBy`, `CreatedDate`, `ModifiedBy`, `ModifiedDate`, `JoinDate`, `LeaveDate`, `LastLogin`, `LastLogout`, `StatusId`, `RoleId`, `ImageName`, `Salary_amount`) VALUES
(2, '2', 'TUYIZERE', 'T', 'Olivier', '1999-08-13', 2, 'pdfcoffee.com_stadium-management-system-pdf-free.pdf', '234644905.pdf', 29, '789633606', 'tuyizereolivier102@gmail.com', 'admin#123', '', 2, 3, 0, 1, '2024-01-06 05:06:37', NULL, NULL, '2024-01-06', '2029-01-05', '2024-01-22 02:57:14', '2024-01-19 17:24:53', 1, 1, '53975david0785556062Photographer(116).jpg', 0),
(3, '35678', 'UWASE', 'T', 'Winny', '2024-01-06', 2, 'pdfcoffee.com_stadium-management-system-pdf-free.pdf', '234644905.pdf', 29, '799633606', 'winnyraceuwase@gmail.com', '1234', '', 2, 2, 0, 1, '2024-01-06 05:37:09', 1, '2024-01-07 11:42:43', '2010-01-06', '2021-01-08', '2024-01-19 20:05:12', '2024-01-19 20:06:41', 1, 3, '1668032023-12-17 012614.png', 232417),
(4, 'MD001', 'Timothy', 'Franklin', 'Fallah', '2024-01-09', 1, 'Cover page.pdf', 'Course (Web Tech).pdf', 29, '781687343', 'timothyfallah@gmail.com', 'admin@123', '', 2, 3, 0, 1, '2024-01-09 05:15:30', NULL, NULL, '2020-01-11', '2027-07-15', '2024-01-22 03:48:09', '2024-01-22 03:16:58', 1, 1, '223515hero.jpg', 3333),
(5, '002', 'Timothy', 'Franklin', 'Fallah', '2024-01-02', 1, 'Cover page.pdf', 'Course (Web Tech).pdf', 29, '781798272', 'timothyfallah31@gmail.com', 'timo@123', '', 2, 5, 0, 1, '2024-01-09 05:18:59', 3, '2024-01-20 01:54:41', '2024-01-18', '2026-03-18', '2024-01-21 12:24:19', '2024-01-20 11:05:49', 1, 3, '203412Screenshot_20230617_234803_Video Player.jpg', 0),
(7, '1478963', 'TUYIZERE', 'ccc', 'Olivier', '2024-01-15', 1, 'Issues of shares.pdf', 'Non profit Organisation.pdf', 21, '789633910', 'tuyizereolivier1020@gmail.com', '12345', '', 2, 5, 1, 1, '2024-01-20 02:00:10', NULL, NULL, '2024-01-09', '2024-01-10', '2024-01-22 02:43:14', NULL, 1, 3, '72313code.jpg', 450000),
(8, 'EM002', 'Joshlyn', 'S.', 'Sony', '2024-01-12', 2, 'Contract sheet.pdf', 'Contract.pdf', 21, '785676545', 'smithhellen@gmail.com', 'Hellen@123', '', 1, 5, 1, 1, '2024-01-22 03:15:55', NULL, NULL, '2024-01-21', '2024-01-21', '2024-01-22 03:43:14', '2024-01-22 03:41:14', 1, 3, '184929Destine.jpg', 450000);

-- --------------------------------------------------------

--
-- Table structure for table `file_uploads`
--

CREATE TABLE `file_uploads` (
  `file_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_description` varchar(255) NOT NULL,
  `uploaded_by` varchar(100) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `file_uploads`
--

INSERT INTO `file_uploads` (`file_id`, `file_name`, `file_description`, `uploaded_by`, `upload_date`) VALUES
(2, 'loans', 'TO WHOM IT MAY CONCERN.pdf', 'tuyizereolivier1020@gmail.com', '2024-01-21 22:29:20'),
(3, 'project', 'docN.pdf', 'tuyizereolivier1020@gmail.com', '2024-01-21 22:44:03'),
(4, 'project', 'docN.pdf', 'tuyizereolivier1020@gmail.com', '2024-01-21 22:45:36'),
(5, 'project', 'docN.pdf', 'tuyizereolivier1020@gmail.com', '2024-01-21 22:46:13'),
(6, 'leave', 'TO WHOM IT MAYCONCERN.pdf', 'tuyizereolivier1020@gmail.com', '2024-01-21 22:47:50');

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

CREATE TABLE `gender` (
  `GenderId` int(11) NOT NULL,
  `Name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gender`
--

INSERT INTO `gender` (`GenderId`, `Name`) VALUES
(1, 'male'),
(2, 'female');

-- --------------------------------------------------------

--
-- Table structure for table `leavedays`
--

CREATE TABLE `leavedays` (
  `LeaveDayId` bigint(20) NOT NULL,
  `LeaveDay` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leavedays`
--

INSERT INTO `leavedays` (`LeaveDayId`, `LeaveDay`) VALUES
(1, 12);

-- --------------------------------------------------------

--
-- Table structure for table `leavedetails`
--

CREATE TABLE `leavedetails` (
  `Detail_Id` bigint(20) NOT NULL,
  `EmpId` varchar(20) NOT NULL,
  `TypesLeaveId` int(10) NOT NULL,
  `Reason` varchar(500) NOT NULL,
  `StateDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `LeaveStatus` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leavedetails`
--

INSERT INTO `leavedetails` (`Detail_Id`, `EmpId`, `TypesLeaveId`, `Reason`, `StateDate`, `EndDate`, `LeaveStatus`) VALUES
(1, '6231415', 3, 'Sample Reason', '2022-10-12', '2022-10-14', 'Accept'),
(2, '35678', 5, 'No Reason', '2023-12-06', '2023-12-07', 'Accept'),
(3, '35678', 3, 'ill', '2023-12-07', '2023-12-08', 'Denied'),
(4, '1478963', 1, 'gsgsg', '2023-12-21', '2023-12-21', 'Denied'),
(5, 'EM002', 4, 'dfghfgh', '2024-01-10', '2024-01-31', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `loans`
--

CREATE TABLE `loans` (
  `loan_id` int(11) NOT NULL,
  `EmployeeId` varchar(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `LoanStatus` enum('Pending','Approved','Closed') NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `request_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loans`
--

INSERT INTO `loans` (`loan_id`, `EmployeeId`, `amount`, `LoanStatus`, `purpose`, `request_date`) VALUES
(2, 'MD002', '6666.00', 'Approved', 'Debt Consolidation', '2024-01-19'),
(3, 'M003', '30000.00', 'Approved', 'Debt Consolidation', '2024-01-19');

-- --------------------------------------------------------

--
-- Table structure for table `maritalstatus`
--

CREATE TABLE `maritalstatus` (
  `MaritalId` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maritalstatus`
--

INSERT INTO `maritalstatus` (`MaritalId`, `Name`) VALUES
(1, 'Married'),
(2, 'Unmarried');

-- --------------------------------------------------------

--
-- Table structure for table `overtime`
--

CREATE TABLE `overtime` (
  `id` int(11) NOT NULL,
  `EmploiyeeId` varchar(20) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `overtime_hours` time NOT NULL,
  `overtime_reason` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `overtime`
--

INSERT INTO `overtime` (`id`, `EmploiyeeId`, `start_time`, `end_time`, `overtime_hours`, `overtime_reason`, `created_at`) VALUES
(1, 'MD001', '22:45:00', '23:45:00', '00:00:01', 'teach', '2024-01-12 20:45:46'),
(2, 'MD002', '22:52:00', '23:52:00', '00:00:01', 'fdfdfd', '2024-01-12 20:52:35'),
(3, 'MD002', '14:09:00', '15:10:00', '00:00:01', 'teaching', '2024-01-19 12:10:53');

-- --------------------------------------------------------

--
-- Table structure for table `paid_loan`
--

CREATE TABLE `paid_loan` (
  `id` int(11) NOT NULL,
  `loan_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE `position` (
  `PositinId` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`PositinId`, `Name`) VALUES
(2, 'Web Developer'),
(3, 'Fullstack PHP Developer'),
(5, 'Lecture');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `project_id` int(11) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `project_file` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT 'Incomplete'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`project_id`, `project_name`, `description`, `start_date`, `end_date`, `project_file`, `created_at`, `status`) VALUES
(1, 'Project A', 'Education Project', '2023-12-21', '2023-12-31', '6584ad5948e16_Covid19-TestCertificate.PDF', '2023-12-21 20:25:45', 'Complete'),
(3, 'Project B', 'fggdfgdfg', '2023-12-22', '2023-12-31', '6584bc430bc8f_olivier.pdf', '2023-12-21 21:29:23', 'Incomplete'),
(4, 'Project c', 'adsad', '2023-12-22', '2023-12-26', '658507bea5d4d_net.pdf', '2023-12-22 02:51:26', 'Incomplete');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `RoleId` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Salary_amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`RoleId`, `Name`, `Salary_amount`) VALUES
(1, 'admin', 60000),
(2, 'admin-hr', 800000),
(3, 'employee', 450000),
(4, 'Head Of Employees', 640000);

-- --------------------------------------------------------

--
-- Table structure for table `salaries`
--

CREATE TABLE `salaries` (
  `id` int(11) NOT NULL,
  `EmployeeId` int(11) NOT NULL,
  `salary_amount` decimal(10,2) NOT NULL,
  `effective_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `StateId` int(11) NOT NULL,
  `CountryId` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`StateId`, `CountryId`, `Name`) VALUES
(1, 15, 'Kigali');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `StatusId` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`StatusId`, `Name`) VALUES
(1, 'active'),
(2, 'inactive');

-- --------------------------------------------------------

--
-- Table structure for table `type_of_leave`
--

CREATE TABLE `type_of_leave` (
  `LeaveId` bigint(20) NOT NULL,
  `Type_of_Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type_of_leave`
--

INSERT INTO `type_of_leave` (`LeaveId`, `Type_of_Name`) VALUES
(1, 'sick leave'),
(3, 'casual leave'),
(4, 'privilege leave'),
(5, 'half day leave');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`announcement_id`);

--
-- Indexes for table `assign_project`
--
ALTER TABLE `assign_project`
  ADD PRIMARY KEY (`assign_id`);

--
-- Indexes for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`CityId`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`CountryId`);

--
-- Indexes for table `dailyworkload`
--
ALTER TABLE `dailyworkload`
  ADD PRIMARY KEY (`DailyWorkLoadId`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`DepartmentId`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`EmpId`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `EmployeeId` (`EmployeeId`),
  ADD UNIQUE KEY `Mobile` (`Mobile`);

--
-- Indexes for table `file_uploads`
--
ALTER TABLE `file_uploads`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexes for table `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`GenderId`);

--
-- Indexes for table `leavedays`
--
ALTER TABLE `leavedays`
  ADD PRIMARY KEY (`LeaveDayId`);

--
-- Indexes for table `leavedetails`
--
ALTER TABLE `leavedetails`
  ADD PRIMARY KEY (`Detail_Id`);

--
-- Indexes for table `loans`
--
ALTER TABLE `loans`
  ADD PRIMARY KEY (`loan_id`);

--
-- Indexes for table `maritalstatus`
--
ALTER TABLE `maritalstatus`
  ADD PRIMARY KEY (`MaritalId`);

--
-- Indexes for table `overtime`
--
ALTER TABLE `overtime`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paid_loan`
--
ALTER TABLE `paid_loan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`PositinId`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`project_id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`RoleId`);

--
-- Indexes for table `salaries`
--
ALTER TABLE `salaries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`StateId`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`StatusId`);

--
-- Indexes for table `type_of_leave`
--
ALTER TABLE `type_of_leave`
  ADD PRIMARY KEY (`LeaveId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `announcement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `assign_project`
--
ALTER TABLE `assign_project`
  MODIFY `assign_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `attendance_records`
--
ALTER TABLE `attendance_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `CityId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `CountryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `dailyworkload`
--
ALTER TABLE `dailyworkload`
  MODIFY `DailyWorkLoadId` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `DepartmentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `EmpId` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `file_uploads`
--
ALTER TABLE `file_uploads`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `gender`
--
ALTER TABLE `gender`
  MODIFY `GenderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `leavedays`
--
ALTER TABLE `leavedays`
  MODIFY `LeaveDayId` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `leavedetails`
--
ALTER TABLE `leavedetails`
  MODIFY `Detail_Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `loans`
--
ALTER TABLE `loans`
  MODIFY `loan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `overtime`
--
ALTER TABLE `overtime`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `paid_loan`
--
ALTER TABLE `paid_loan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `position`
--
ALTER TABLE `position`
  MODIFY `PositinId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `RoleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `salaries`
--
ALTER TABLE `salaries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `StateId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `type_of_leave`
--
ALTER TABLE `type_of_leave`
  MODIFY `LeaveId` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
