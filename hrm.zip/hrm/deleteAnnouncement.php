<?php
include_once('controller/connect.php');
  
$dbs = new database();
$db = $dbs->connection();

if (isset($_GET['announcementId'])) {
    $announcementId = $_GET['announcementId'];

    // Perform deletion
    $deleteQuery = "DELETE FROM announcements WHERE announcement_id = '$announcementId'";
    if ($db->query($deleteQuery)) {
        // Successfully deleted
        header("Location: ../viewAnnouncements.php");
        exit();
    } else {
        // Error in deletion
        echo "Error deleting announcement: " . $db->error;
    }
} else {
    // No announcementId provided
    echo "Invalid request";
}
?>
