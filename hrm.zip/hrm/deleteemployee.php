<?php 
$conn=mysqli_connect("localhost","root","","hrm_db");
$em=$_GET['Email'];
$qry=mysqli_query($conn,"DELETE FROM employee WHERE Email = '$em' ");
echo"<script>window.alert('Employed Deleted successfully');window.location='employeeview.php';</script>";

?>