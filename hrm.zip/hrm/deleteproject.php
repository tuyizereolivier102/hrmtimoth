<?php
include_once('controller/connect.php');

$dbs = new database();
$db = $dbs->connection();

if (isset($_GET['project_id']) && !empty($_GET['project_id'])) {
    $project_id = $_GET['project_id'];

    // Assuming your project table is named 'project'
    $sql = "DELETE FROM project WHERE project_id = $project_id";

    if (mysqli_query($db, $sql)) {
        echo "Project deleted successfully";
        header("location:projectview.php");
               
    } else {
        echo "Error deleting project: " . mysqli_error($db);
    }
} else {
    echo "Invalid project ID";
}

mysqli_close($db);
?>
