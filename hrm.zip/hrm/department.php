<?php include('header.php'); ?>
<?php 
  include_once('controller/connect.php');
  
  $dbs = new database();
  $db=$dbs->connection();
  $did="";
  
  if(isset($_GET['departmentedit']))
  {
    $departmentid = $_GET['departmentedit'];
    $edit = mysqli_query($db,"select * from department where DepartmentId='$departmentid'");
    $row = mysqli_fetch_assoc($edit);
    $did = $row['Name'];
  }

  $page="";
  if(isset($_GET['searchdepartment']))
  {
    $SearchDepartmentName = $_GET['searchdepartment'];
    
    $RecordLimit = 5;
    $searchDepartment = mysqli_query($db,"select count(DepartmentId) as total from department where Name like '%".$SearchDepartmentName."%'");
    $DepartmentCount = mysqli_fetch_array($searchDepartment);
    
    $number_of_row = ceil($DepartmentCount['total'] / $RecordLimit); 

    if(isset($_GET['bn']) && intval($_GET['bn']) <= $number_of_row && intval($_GET['bn'] != 0))
    {
      $Skip = (intval($_GET["bn"]) * $RecordLimit) - $RecordLimit;
      $sql = mysqli_query($db,"select * from department where Name like '%".$SearchDepartmentName."%' LIMIT $Skip, $RecordLimit");
    }
    else
    {
      $sql = mysqli_query($db,"select * from department where Name like '%".$SearchDepartmentName."%' LIMIT $RecordLimit");
    }

    for($i=0; $i<$number_of_row; $i++)
    {
      $d = $i + 1;
      if(isset($_GET["searchdepartment"]))
      {
        $page .= "<a href='department.php?searchdepartment=$SearchDepartmentName&bn=$d'>$d</a>&nbsp &nbsp &nbsp";
      }
      else
      {
        $page .= "<a href='department.php?bn=$d'>$d</a>&nbsp &nbsp &nbsp";
      }                   
    } 
  }
  else
  {
    $RecordLimit = 5;
    $searchDepartment = mysqli_query($db,"select count(DepartmentId) as total from department");
    $DepartmentCount = mysqli_fetch_array($searchDepartment);
    
    $number_of_row = ceil($DepartmentCount['total'] / $RecordLimit);
    if(isset($_GET['bn']) && intval($_GET['bn']) <= $number_of_row && intval($_GET['bn'] != 0 ))
    {
      $Skip = (intval($_GET["bn"]) * $RecordLimit) - $RecordLimit;
      $sql = mysqli_query($db,"select * from department LIMIT $Skip, $RecordLimit");
    }
    else
    {
      $sql = mysqli_query($db,"select * from department LIMIT $RecordLimit");
    }

    for($i=0; $i<$number_of_row; $i++)
    {
        $d = $i + 1;
        $page .= "<a href='department.php?bn=$d'>$d</a>&nbsp &nbsp &nbsp";
    }
  }
?>
<link rel="stylesheet" type="text/css" href="css/table-style.css" />
<script type="text/javascript" src="js/jquery.basictable.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
      $('#table').basictable();

      // ... (other script for table functionalities)

    });
</script>
<ol class="breadcrumb" style="margin: 10px 0px ! important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Table Master<i class="fa fa-angle-right"></i>Department</li>
</ol>

<div class="validation-system" style="margin-top: 0;display:flex">
    
    <div class="validation-form" style="overflow: auto; margin-right:20px; height: 450px; width: 49%; float: left;">
        <form method="POST" action="controller/ccity.php?departmentedit=<?php echo isset($row['DepartmentId']) ? $row['DepartmentId'] : ''; ?>">
        <div class="vali-form-group" >
            <h2>Add Department</h2>
            <div class="col-md-3 control-label">
              <label class="control-label">Department</label>
                <div class="input-group">             
                    <span class="input-group-addon">
                    <i class="fa fa-building" aria-hidden="true"></i>
                  </span>
                <input type="text" name="department" required="" value="<?php echo $did; ?>" placeholder="Department Name" class="form-control" style="width: 250px; height: 35px; float: right;">
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
            <div class="col-md-12 form-group">
              <button type="submit" name="departmenty" class="btn btn-primary">Add</button>
              <button type="button" onclick="location.href = 'department.php'" class="btn btn-default">Reset</button>
            </div>
          <div class="clearfix"> </div>
        </form>
    </div>

    <div class="validation-form" style="width: 49%; overflow: auto;">
        <div style="height: 396px;">
          <div class="w3l-table-info">
            <h2>Department</h2>
            <br>
            <form method="GET" action="#">
              <input style="float: right;" type="submit" name="searchdepartment">
              <input style="float: right;" placeholder="Search..." type="search-box" name="searchdepartment" value="<?php echo(isset($_GET['searchdepartment'])) ? $_GET['searchdepartment'] : ""; ?>"><br>
            </form>
            <table id="table">
              <thead>
                <tr>
                  <th>Id</th>
                  <th style="width: 5000px;">Name</th>
                  <th style="text-align: center; width: 450px;">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $i=1; while($row = mysqli_fetch_assoc($sql)) { ?> 
                  <tr>
                    <td><?php if(isset($_GET['bn'])==0){ echo $i; } else{ echo ($_GET['bn']-1)*5+$i; } $i++; ?></td>
                    <td><?php echo ucfirst($row['Name']); ?></td>
                    <td><a href="?departmentedit=<?php echo $row['DepartmentId']; ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="controller/cdepartment.php?departmentdelete=<?php echo $row['DepartmentId']; ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
            <div><?php echo $page; ?></div>
          </div>
        </div>
    </div>
</div>
<?php include('footer.php'); ?>
