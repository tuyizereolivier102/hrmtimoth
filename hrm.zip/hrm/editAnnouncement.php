<?php
// controller/editAnnouncement.php
include_once('controller/connect.php');
  
$dbs = new database();
$db = $dbs->connection();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['announcementId'])) {
    $announcementId = $_POST['announcementId'];
    $newTitle = $_POST['newTitle'];
    $newContent = $_POST['newContent'];
    $newExpirationDate = $_POST['newExpirationDate'];

    // Perform update
    $updateQuery = "UPDATE announcements SET title = '$newTitle', content = '$newContent', expiration_date = '$newExpirationDate' WHERE announcement_id = '$announcementId'";
    if ($db->query($updateQuery)) {
        // Successfully updated
        header("Location: ../viewAnnouncements.php");
        exit();
    } else {
        // Error in update
        echo "Error updating announcement: " . $db->error;
    }
} else {
    // Invalid request
    echo "Invalid request";
}
?>
