<?php include('header.php'); ?>

<?php 
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();
?>

<ol class="breadcrumb" style="margin: 10px 0px ! important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Employee Loans</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <h2>Employee Loans</h2>

        <form method="POST" action="controller/approveLoan.php" enctype="multipart/form-data">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Employee ID</th>
                        <th>Employee Name</th>
                        <th>Loan ID</th>
                        <th>Loan Amount</th>
                        <th>Loan Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $employeeLoansQuery = mysqli_query($db, "SELECT e.EmployeeId, CONCAT(e.FirstName, ' ', e.LastName) AS FullName, l.loan_id, l.amount, l.LoanStatus FROM employee e LEFT JOIN loans l ON e.EmployeeId = l.EmployeeId WHERE  l.amount > 0");

                    while ($row = mysqli_fetch_assoc($employeeLoansQuery)) {
                        echo "<tr>";
                        echo "<td>{$row['EmployeeId']}</td>";
                        echo "<td>{$row['FullName']}</td>";
                        echo "<td>{$row['loan_id']}</td>";
                        echo "<td>{$row['amount']}</td>";
                        echo "<td>{$row['LoanStatus']}</td>";
                        
                        // Button colors
                        $confirmBtnColor = 'btn btn-success';
                        $denyBtnColor = 'btn btn-danger';
                        $deleteBtnColor = 'btn btn-warning';
                        
                        echo "<td><button type='submit' name='submit' class='{$confirmBtnColor}' value='{$row['loan_id']}'>Confirm</button></td>";
                        echo "<td><button type='submit' name='submit1' class='{$denyBtnColor}' value='{$row['loan_id']}'>Deny</button></td>";
                        echo "<td><button type='submit' name='delete' class='{$deleteBtnColor}' value='{$row['loan_id']}'>Delete</button></td>";
                        echo "<td><input type='hidden' name='loan_id' value='{$row['loan_id']}'></td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </form>
    </div> 
</div>

<?php include('footer.php'); ?>
