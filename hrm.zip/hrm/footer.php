<!DOCTYPE html>
<!-- Coding By CodingNepal - www.codingnepalweb.com -->
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/css/all.min.css">
    <!-- Fontawesome Link for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <style>
        /* Add the following styles to change background and menu color */

        .sidebar-menu {
            background-color: #060072;
        }

        .sidebar-menu a {
            color: #3d72ff;
        }
    </style>
</head>
<!-- script-for sticky-nav -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        var navoffset = $(".header-main").offset().top;
        $(window).scroll(function() {
            var scrollpos = $(window).scrollTop();
            if (scrollpos >= navoffset) {
                $(".header-main").addClass("fixed");
            } else {
                $(".header-main").removeClass("fixed");
            }
        });

    });
</script><?php error_reporting(0);?>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->

<!--inner block end here-->
<!--copy rights start here-->
<div style="margin-top: -20px;" class="copyrights">
	 <p>Copyright © UNILAK <?= date("Y") ?>|| Human Resource Management System </p>
</div>	
<!--COPY rights end here-->
</div>
</div>
  <!--//content-inner-->
			<!--/sidebar-menu-->
				<div class="sidebar-menu" style="">
					<header class="logo1">
						<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a>
					</header>
						<div style="background-color:royalblue ;border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu" >

									<ul id="menu"  style="background-color:royalblue ;" >
										<li><a href="home.php"><i class="fa fa-tachometer"></i> <span>Dashboard	</span><div class="clearfix"></div></a></li>

										<li><a href="#"><i class="fa fa-user"></i><span>Employee</span><span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
											<ul>
												<li><a href="employeeadd.php">Add Employee</a></li>
												<li><a href="employeeview.php">Employee View</a></li>
												<!-- <li><a href="atten.php">Attendece Details</a></li>
												<li><a href="modifiedlogout.php">Modified Logout Time</a></li>
												<li><a href="inquiry.php">Inquiry</a></li> -->
											</ul>
										</li>
										
										<li><a href="#"><i class="fa fa-check" aria-hidden="true"></i><span>Attendance</span><span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
											<ul>
												<li><a href="record_attendance.php">Record Attendance</a></li>
												
												<li><a href="viewdate.php">Attendance Dates</a></li>
												<li><a href="viewattend.php">Monthly Attendance</a></li>
												
											</ul>
										</li>
										<li><a href="#"><i class="fa fa-cube"></i><span>Projects</span><span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
											<ul>
												<li><a href="projectadd.php">Add Project</a></li>
												<li><a href="projectview.php">View Project</a></li>
												<li><a href="assignproject.php">Assign Project</a></li>
												<li><a href="viewassignedproject.php">View Assigned Project</a></li>
												<!-- <li><a href="atten.php">Attendece Details</a></li>
												<li><a href="modifiedlogout.php">Modified Logout Time</a></li>
												<li><a href="inquiry.php">Inquiry</a></li> -->
											</ul>
										</li>
										<li><a href="leaverequest.php"><i class="fa fa-pagelines"></i><span>Leave</span></a>
											
										<li><a href="salarydashboard.php"><i class="fas fa-hand-holding-usd"></i></i><span>Salary</span><span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
											<ul>
												<li><a href="employee-loans.php">View Loans</a></li>
												<li><a href="loans.php">View Paid Loans</a></li>
												
												<!-- <li><a href="atten.php">Attendece Details</a></li>
												<li><a href="modifiedlogout.php">Modified Logout Time</a></li>
												<li><a href="inquiry.php">Inquiry</a></li> -->
											</ul>
										</li>
										<li><a href="clearingsalary.php"><i class="fas fa-edit"></i><span> Activity</span><div class="clearfix"></div></a>
											
										</li>

										
							        	<li id="menu-academico" ><a href="changepassword.php"><i class="fa fa-cogs"></i><span>Change Password</span></a> <!-- <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div>
										 <ul id="menu-academico-sub">
											<li id="menu-academico-avaliacoes" ><a href="changepassword.php">Change Password</a></li>
											

										  </ul> -->
									 	</li>

										<li><a href="#"><i class="fa fa-check-square-o nav_icon"></i><span>Forms</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										  	<ul>
												<li><a href="loan_request.php">Loan Request</a></li>
												<li><a href="loan_payment.php">Loan Payment</a></li>
												<li><a href="overtime.php">Overtime</a></li>
												<li><a href="viewovertime.php">View Overtime</a></li>
												<li><a href="announcement.php">Announcement</a></li>
											</ul>
										</li>

										<li><a href="#"><i class="fa fa-list"></i><span>Master List</span> <span class="fa fa-angle-right" style="float: right"></span><div class="clearfix"></div></a>
										  	<ul>
												<li><a href="city.php">City</a></li>
												<li><a href="state.php">State</a></li>
												<li><a href="country.php">Country</a></li>
												<li><a href="position.php">Position</a></li>
												<li><a href="roleadd.php">Role</a></li>
												<li><a href="department.php">Department</a></li>
											</ul>
										</li>
										
								  </ul>
								</div>
							  </div>
							  <div class="clearfix"></div>		
							</div>
							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});
							</script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->	   

</body>
</html>