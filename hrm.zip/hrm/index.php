<?php
    $result ="";
    if(isset($_GET['msg']))
    {
        $result=$_GET['msg'];
    }
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>Login Page - HRM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha384-GLhlTQ8iM01OdEVZMzK8NCSCtiM9T9Hj2BzhrOtMz9tlSjkP5F5C99ecH9MIEnjN" crossorigin="anonymous">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background-image: linear-gradient(darkblue, cyan );
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }

        .login-container {
            background-color: white; /* Adjust the opacity as needed */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
            width: 800px;
            height:580px;
            max-width: 100%;
            padding: 20px;
            text-align: center;
        }

        .login-container h1 {
            color: darkblue;
            margin-bottom: 0px;
        }

        .email {
            position: relative;
            width: 100%;
            align-items: center;
        }

        .email input[type="email"] {
            width: 50%;
            padding: 12px;
            margin: 8px 8px;
            margin-bottom: -3px;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-sizing: border-box;
            outline: none;
            border-bottom-color: darkblue;
            border-top-color: orangered;
        }

        .email i {
            position: absolute;
            top: 50%;
            right: 10px;
            transform: translateY(-50%);
            color: blue;
            cursor: pointer;
        }

        .login-form input[type="password"] {
            width: 50%;
            padding: 12px;
            margin: 6px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
            outline: none;
            border-radius: 8px;
            border-bottom-color: darkblue;
            border-top-color: orangered;

        }

        .login-form input[type="submit"] {
            background-color: darkblue;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            margin-bottom: 15px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }

        .login-form input[type="submit"]:hover {
            background-color: orangered;
        }

        .login-form h4 {
            color: #F1C40F;
            margin: 10px 0;
        }

        .login-form a {
            color: darkblue;
            text-decoration: none;
            font-size: 20px;
        }

        .login-form a:hover {
            text-decoration: underline;
            color: orangered;
        }

        .eye-icon {
            cursor: pointer;
            color: #95a5a6;
        }

        .login-container img {
            max-width: 100%;
            height: auto;
            margin-top: 20px;
        }
        .login-image {
        align-items: center;
        
    }

    .login-image img {
        border-radius: 60%;
        
    }
        .footer p{
            color: darkblue;
    }
        .login-container h2{
            color: darkred;
        }

    </style>
</head>
<body>
    <div class="login-container">
        <h1>Human Resource Management System</h1>
        <div class="login-image">
        <img src="images/unilak.jpg""height 150" width="150" alt="Unilak Logo">
        </div>
        <h2>ADMIN</h2>
        <form action="controller/login.php" method="post" class="login-form">
            <div class="email">
                <input type="email" name="name" placeholder="Enter Email Address" required>
                <i class="fa fa-envelope"></i>
            </div>
            <br>
            <input type="password" name="password" id="Psw" placeholder="Enter Password" required>
            <i class="fa fa-eye-slash eye-icon" onclick="togglePasswordVisibility();"></i>
            <h4><?php echo $result; ?></h4>
            <input type="submit" name="submit" value="Sign In">
            <br>
            <h5><a href="./user">Login as an Employee</a></h5>
            <br><br><br>
        </form>
        
        <div class="footer">
            <p>CopyrightK&copy; <?= date("Y") ?> UNILAK||Human Resource Management System. All Rights Reserved.</p>
        </div>
        
        
    </div>

    <script>
        function togglePasswordVisibility() {
            var passwordField = document.getElementById("Psw");
            var eyeIcon = document.querySelector(".eye-icon");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                eyeIcon.classList.remove("fa-eye-slash");
                eyeIcon.classList.add("fa-eye");
            } else {
                passwordField.type = "password";
                eyeIcon.classList.remove("fa-eye");
                eyeIcon.classList.add("fa-eye-slash");
            }
        }
    </script>
</body>
</html>
