<?php include('header.php'); ?>

<?php 
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();
?>

<ol class="breadcrumb" style="margin: 10px 0px !important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Record Loan Payment</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <h2>Record Loan Payment</h2>

        <form method="POST" action="controller/recordLoanPayment.php" enctype="multipart/form-data">
            <!-- Employee ID -->
            <div class="col-md-4 control-label">
                <label class="control-label">Employee ID</label>
                <div class="input-group">             
                    <span class="input-group-addon">
                        <i class="fa fa-user" aria-hidden="true"></i>
                    </span>
                    <select name="empid" id="empid" title="Employee" class="form-control" required>
                        <option value="">-- Select Employee --</option>
                        <?php 
                            $employeeQuery = mysqli_query($db, "SELECT EmployeeId, CONCAT(FirstName, ' ', LastName) AS FullName FROM employee");
                            while ($row = mysqli_fetch_assoc($employeeQuery)) {
                                echo "<option value='{$row['EmployeeId']}'>{$row['FullName']}</option>";
                            }
                        ?>
                    </select>
                </div>
            </div>

           

            <!-- Loan Amount -->
            <div class="col-md-4 control-label">
                <label class="control-label">Loan Amount</label>
                <div class="input-group">             
                    <span class="input-group-addon">
                        <i class="fa fa-money" aria-hidden="true"></i>
                    </span>
                    <input type="text" name="loanAmount" id="loanAmount" class="form-control" readonly>
                </div>
            </div>

            <!-- Payment Amount -->
            <div class="col-md-4 control-label">
                <label class="control-label">Payment Amount</label>
                <div class="input-group">             
                    <span class="input-group-addon">
                        <i class="fa fa-usd" aria-hidden="true"></i>
                    </span>
                    <input type="text" name="payment_amount" class="form-control" placeholder="Enter payment amount" required>
                </div>
            </div>

            <!-- Payment Date -->
            <div class="col-md-4 control-label">
                <label class="control-label">Payment Date</label>
                <div class="input-group">             
                    <span class="input-group-addon">
                        <i class="fa fa-calendar" aria-hidden="true"></i>
                    </span>
                    <input type="date" name="payment_date" class="form-control" required>
                </div>
            </div>

            <div class="col-md-12 form-group">
                <button type="submit" name="submit" class="btn btn-primary">Record Payment</button>
                <button type="reset" class="btn btn-default">Reset</button>
            </div>
            <div class="clearfix"></div>
        </form>
    </div> 
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        // Fetch and update total loan amount based on selected employee
        $('#empid').change(function() {
            var empid = $(this).val();
            
            $.ajax({
                type: 'POST',
                url: 'controller/getLoanIds.php',
                data: { empid: empid },
                dataType: 'json', // Expect JSON response
                success: function(response) {
                    if (response.totalLoanAmount !== null) {
                        // Set the total loan amount in the input field
                        $("#loanAmount").val(response.totalLoanAmount);
                    } else {
                        // Clear the input field if no loan is found
                        $("#loanAmount").val("");
                    }
                },
                error: function(error) {
                    console.error('Error fetching total loan amount:', error);
                }
            });
        });
    });
</script>


<?php include('footer.php'); ?>
