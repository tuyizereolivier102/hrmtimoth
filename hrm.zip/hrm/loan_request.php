<?php include('header.php'); ?>

<?php 
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();
$loanPurposes = array("Home Improvement", "Education", "Medical Expenses", "Debt Consolidation", "Other");

?>

<ol class="breadcrumb" style="margin: 10px 0px !important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Request Loan</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <h2>Request Loan</h2>

        <form method="POST" action="controller/requestLoan.php" enctype="multipart/form-data">
            <!-- Employee ID -->
            <div class="col-md-4 control-label">
                <label class="control-label">Employee ID</label>
                <div class="input-group">             
                    <span class="input-group-addon">
                        <i class="fa fa-user" aria-hidden="true"></i>
                    </span>
                    <select name="empid" id="empid" title="Employee" class="form-control" required>
                        <option value="">-- Select Employee --</option>
                        <?php 
                            $employeeQuery = mysqli_query($db, "SELECT EmployeeId, CONCAT(FirstName, ' ', LastName) AS FullName FROM employee");
                            while ($row = mysqli_fetch_assoc($employeeQuery)) {
                                echo "<option value='{$row['EmployeeId']}'>{$row['FullName']}-->{$row['EmployeeId']}</option>";
                            }
                        ?>
                    </select>
                </div>
            </div>
           
        <div class="col-md-4 control-label">
                <label class="control-label">Purpose</label>
                <div class="input-group">             
                    <span class="input-group-addon">
                        <i class="fa fa-bible" aria-hidden="true"></i>
                    </span>
                    <select name="purpose" id="empid" title="Purpose" class="form-control" required>
                        <option value="">-- Select a purpose --</option>
                        <?php
            // Populate loan purposes dropdown
            foreach ($loanPurposes as $loanPurpose) {
                echo "<option value=\"$loanPurpose\">$loanPurpose</option>";
            }
            ?>
                           
                       
                    </select>
                </div>
            </div>
            <!-- Loan Amount -->
            <div class="col-md-4 control-label">
                <label class="control-label">Loan Amount</label>
                <div class="input-group">             
                    <span class="input-group-addon">
                        <i class="fa fa-money" aria-hidden="true"></i>
                    </span>
                    <input type="text" name="loanAmount" class="form-control" placeholder="Enter loan amount" required>
                </div>
            </div>


            <div class="col-md-12 form-group">
                <button type="submit" name="submit" class="btn btn-primary">Submit Loan Request</button>
                <button type="reset" class="btn btn-default">Reset</button>
            </div>
            <div class="clearfix"></div>
        </form>
    </div> 
</div>

<?php include('footer.php'); ?>
