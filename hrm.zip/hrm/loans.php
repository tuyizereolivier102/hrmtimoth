<?php
include('header.php');

include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();
?>

<ol class="breadcrumb" style="margin: 10px 0px !important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Employee Loans</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <h2>Employee Loans</h2>

        <form method="POST" action="controller/approveLoan.php" enctype="multipart/form-data">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Employee ID</th>
                        <th>Employee Name</th>
                        <th>Total Loan Amount</th>
                        <th>Paid Amount</th>
                        <th>Remaining Amount</th>
                        <th>Loan Status</th>
                        <!-- Add any additional columns you need -->
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $employeeLoansQuery = mysqli_query($db, "SELECT e.EmployeeId, CONCAT(e.FirstName, ' ', e.LastName) AS FullName, SUM(l.amount) AS totalLoanAmount, l.LoanStatus FROM employee e LEFT JOIN loans l ON e.EmployeeId = l.EmployeeId WHERE l.amount > 0 GROUP BY e.EmployeeId");

                        while ($row = mysqli_fetch_assoc($employeeLoansQuery)) {
                            $employeeId = $row['EmployeeId'];
                            $totalLoanAmount = $row['totalLoanAmount'];
                            $paidAmount = calculatePaidAmount($employeeId, $db);
                            $remainingAmount = $totalLoanAmount - $paidAmount;

                            echo "<tr>";
                            echo "<td>{$employeeId}</td>";
                            echo "<td>{$row['FullName']}</td>";
                            echo "<td>{$totalLoanAmount}</td>";
                            echo "<td>{$paidAmount}</td>";
                            echo "<td>{$remainingAmount}</td>";
                            echo "<td>{$row['LoanStatus']}</td>";
                            // Add any additional columns you need
                            echo "</tr>";
                        }
                    ?>

                    <?php
                        function calculatePaidAmount($employeeId, $db) {
                            // Use single quotes around the employee ID
                            $paidAmountQuery = mysqli_query($db, "SELECT SUM(amount_paid) AS paidAmount FROM paid_loan pl LEFT JOIN loans l ON pl.loan_id = l.loan_id WHERE l.EmployeeId = '$employeeId'");
                            $paidAmountRow = mysqli_fetch_assoc($paidAmountQuery);

                            return $paidAmountRow['paidAmount'] ?? 0;
                        }
                    ?>
                </tbody>
            </table>
        </form>
    </div> 
</div>

<?php include('footer.php'); ?>
