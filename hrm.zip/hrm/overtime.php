<?php include('header.php'); ?>

<?php
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();

?>

<ol class="breadcrumb" style="margin: 10px 0px ! important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Overtime Request</li>
</ol>

<!--grid-->
<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <form method="POST" action="" enctype="multipart/form-data" id="overtimeForm">

            <!-- Other form fields -->

            <!-- Employee ID -->
            <div class="col-md-4 control-label">
                <label class="control-label">Employee</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-user" aria-hidden="true"></i>
                    </span>
                    <select name="empid" title="Employee" class="form-control" required>
                        <option value="">-- Select Employee --</option>
                        <?php
                        $employeeQuery = mysqli_query($db, "SELECT EmployeeId, CONCAT(FirstName, ' ', LastName) AS FullName FROM employee");
                        while ($row = mysqli_fetch_assoc($employeeQuery)) {
                            echo "<option value='{$row['EmployeeId']}'>{$row['FullName']}-->{$row['EmployeeId']}</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <!-- Start Time -->
            <div class="col-md-4 control-label">
                <label class="control-label">Start Time</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    <input type="time" name="startTime" id="startTime" class="form-control" required>
                </div>
            </div>

            <!-- End Time -->
            <div class="col-md-4 control-label">
                <label class="control-label">End Time</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    <input type="time" name="endTime" id="endTime" class="form-control" required>
                </div>
            </div>

            <!-- Overtime Hours -->
            <div class="col-md-12 control-label">
                <label class="control-label">Overtime Hours</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-clock-o" aria-hidden="true"></i>
                    </span>
                    <input type="text" name="overtimeHours" id="overtimeHours" class="form-control" readonly>
                </div>
            </div>

            <!-- Reason for Overtime -->
            <div class="col-md-12 control-label">
                <label class="control-label">Reason for Overtime</label>
                <textarea name="overtimeReason" class="form-control" rows="3" required></textarea>
            </div>

            <!-- Other form fields -->

            <div class="col-md-12 form-group">
                <button type="submit" name="submitOvertime" class="btn btn-primary">Submit Overtime Request</button>
                <button type="reset" class="btn btn-default">Reset</button>
            </div>
            <div class="clearfix"> </div>
        </form>
    </div>
</div>

<!-- Results Display -->
<div id="overtimeResults"></div>

<?php include('footer.php'); ?>

<!-- AJAX Script -->
<script>
    document.getElementById('overtimeForm').addEventListener('submit', function (event) {
        event.preventDefault();

        // Fetch and display overtime request results using AJAX
        var formData = new FormData(this);
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'controller/overtime.php', true);
        xhr.onload = function () {
            if (xhr.status === 200) {
                document.getElementById('overtimeResults').innerHTML = xhr.responseText;

                // Clear the form after successful submission
                document.getElementById('overtimeForm').reset();
            }
        };
        xhr.send(formData);
    });

    // Calculate overtime hours on input change
    document.getElementById('endTime').addEventListener('change', function () {
        calculateOvertime();
    });

    document.getElementById('startTime').addEventListener('change', function () {
        calculateOvertime();
    });

    function calculateOvertime() {
        var startTime = document.getElementById('startTime').value;
        var endTime = document.getElementById('endTime').value;

        if (startTime && endTime) {
            var start = new Date("1970-01-01 " + startTime);
            var end = new Date("1970-01-01 " + endTime);

            var diff = end - start;

            if (diff < 0) {
                diff += 24 * 60 * 60 * 1000; // Add 24 hours
            }

            var hours = Math.floor(diff / 3600000);
            var minutes = Math.floor((diff % 3600000) / 60000);

            var overtimeHours = hours + (minutes / 60);

            if (overtimeHours > 0 && overtimeHours < 2) {
                document.getElementById('overtimeHours').value = overtimeHours.toFixed(2);
            } else {
                alert("Overtime hours must be greater than 0 and less than 2.");
                document.getElementById('overtimeHours').value = "";
                document.getElementById('startTime').value = "";
                document.getElementById('endTime').value = "";
            }
        }
    }
</script>
