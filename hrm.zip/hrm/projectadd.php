<?php include('header.php'); ?>

<?php
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();

$result = "";
$id = "";

if (isset($_GET['msg'])) {
    $result = $_GET['msg'];
} else if (isset($_GET['id'])) {
    $id = $_GET['id'];
}
?>

<ol class="breadcrumb" style="margin: 10px 0px !important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i> Project <i class="fa fa-angle-right"></i> Project Add</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <!---->
        <form method="POST" action="controller/project.php" enctype="multipart/form-data">
            <?php
            if ($result) {
                echo '<h4 style="color: #FF0000;">' . $result . '</h4>';
            } else {
                echo '<h4 style="color: #008000;">' . $id . '</h4>';
            }
            ?>
            <div class="vali-form-group">
                <div class="col-md-6 control-label">
                    <label class="control-label">Project Name*</label>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="fa fa-tasks" aria-hidden="true"></i>
                        </span>
                        <input type="text" name="project_name" title="Project Name" class="form-control" placeholder="Project Name" required="">
                    </div>
                </div>

                <div class="col-md-6 control-label">
                    <label class="control-label">Description</label>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="fa fa-info" aria-hidden="true"></i>
                        </span>
                        <textarea name="description" title="Description" class="form-control" placeholder="Project Description"></textarea>
                    </div>
                </div>
            </div>

            <div class="vali-form-group">
                <div class="col-md-6 control-label">
                    <label class="control-label">Start Date</label>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                        </span>
                        <input type="text" id="start_date" name="start_date" title="Start Date" placeholder="Start Date" class="form-control" required="">
                    </div>
                </div>

                <div class="col-md-6 control-label">
                    <label class="control-label">End Date</label>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <i class="fa fa-calendar" aria-hidden="true"></i>
                        </span>
                        <input type="text" id="end_date" name="end_date" title="End Date" placeholder="End Date" class="form-control">
                    </div>
                </div>
            </div>

            <div class="col-md-12 control-label">
                <label class="control-label">Project File*</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-upload" aria-hidden="true"></i>
                    </span>
                    <input type="file" name="project_file" title="Project File" class="form-control" required="">
                </div>
            </div>

            <div class="clearfix"> </div>

            <div class="col-md-12 form-group">
                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                <button type="reset" class="btn btn-default">Reset</button>
            </div>

            <div class="clearfix"> </div>
        </form>
        <!---->
    </div>
</div>

<script>
    $('#start_date').datetimepicker({
        yearOffset: 0,
        lang: 'ch',
        timepicker: false,
        format: 'Y/m/d',
        formatDate: 'Y/m/d',
        minDate: '0', // Today is the minimum date
    });

    $('#end_date').datetimepicker({
        yearOffset: 0,
        lang: 'ch',
        timepicker: false,
        format: 'Y/m/d',
        formatDate: 'Y/m/d',
        //minDate: '0', // Uncomment this if the end date should not be before today
    });
</script>

<?php include('footer.php'); ?>
