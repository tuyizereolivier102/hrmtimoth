<?php include('header.php'); ?>
<?php
	include_once('controller/connect.php');
	
	$dbs = new database();
	$db = $dbs->connection();

	// Check if project_id is provided in the URL
	if (isset($_GET['project_id'])) {
		$project_id = $_GET['project_id'];

		// Fetch project details from the database
		$query = mysqli_query($db, "SELECT * FROM project WHERE project_id = '$project_id'");
		$project = mysqli_fetch_assoc($query);

		if (!$project) {
			// Project not found, you may redirect or display an error message
			echo "Project not found!";
		}
	} else {
		// Redirect or display an error message if project_id is not provided
		echo "Invalid project ID!";
	}
?>

<link rel="stylesheet" type="text/css" href="css/projectdetails-style.css" />
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<ol class="breadcrumb" style="margin: 10px 0px ! important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Project<i class="fa fa-angle-right"></i>Project Details</li>
</ol>
<style>
	/* projectdetails-style.css */

body {
    font-size: 18px; /* Increase the base font size */
}

.card {
    width: 70%; /* Adjust the width of the card */
    margin: 0 auto; /* Center the card on the page */
    margin-top: 50px; /* Add top margin for better spacing */
}

.card-body {
    padding: 20px; /* Add padding to the card body */
}

.table {
    font-size: 16px; /* Increase font size within the table */
}

.breadcrumb {
    font-size: 18px; /* Increase breadcrumb font size */
}

</style>
<div class="container mt-4">
	<div class="card">
		<div class="card-header">
			<h2 class="text-center">Project Details</h2>
		</div>
		<div class="card-body">
			<table class="table" style="color:black;">
				<tr>
					<td><strong>Project Name:</strong></td>
					<td><?php echo $project['project_name']; ?></td>
				</tr>
				<tr>
					<td><strong>Description:</strong></td>
					<td><?php echo $project['description']; ?></td>
				</tr>
				<tr>
					<td><strong>Start Date:</strong></td>
					<td><?php echo $project['start_date']; ?></td>
				</tr>
				<tr>
					<td><strong>End Date:</strong></td>
					<td><?php echo $project['end_date']; ?></td>
				</tr>
				<tr>
					<td><strong>Project File:</strong></td>
					<td>
						<?php
						// Display a link to view the project file
						$file_path = "project_file/" . $project['project_file'];
						if (file_exists($file_path)) {
							echo "<a href='$file_path' target='_blank'>View File</a>";
						} else {
							echo "File not found";
						}
						?>
					</td>
				</tr>
				<tr>
					<td><strong>Status:</strong></td>
					<td><?php echo $project['status']; ?></td>
				</tr>
			</table>
		</div>
	</div>
</div>

<?php include('footer.php'); ?>
