<?php include('header.php'); ?>
<?php
	include_once('controller/connect.php');
	
	$dbs = new database();
	$db=$dbs->connection();

	$page = "";
	if (isset($_GET['search'])) {
		$SearchName = $_GET['search'];
		$RecordeLimit = 10;
		$search = mysqli_query($db, "SELECT COUNT(project_id) as total FROM project WHERE project_name LIKE '%" . $SearchName . "%'");
		
		$SName = mysqli_fetch_array($search);
		
		$number_of_row = ceil($SName['total'] / 10); 
		if (isset($_GET['bn']) && intval($_GET['bn']) <= $number_of_row && intval($_GET['bn'] != 0)) {

			$Skip = (intval($_GET["bn"]) * $RecordeLimit) - $RecordeLimit;

			$sql = mysqli_query($db, "SELECT * FROM project WHERE project_name LIKE '%" . $SearchName . "%' LIMIT $Skip, $RecordeLimit");
		} else {
			$sql = mysqli_query($db, "SELECT * FROM project WHERE project_name LIKE '%" . $SearchName . "%' LIMIT $RecordeLimit");
		}

		for ($i = 0; $i < $number_of_row; $i++) {
			$d = $i + 1;
			if (isset($_GET["search"])) {
				$page .= "<a href='?search=$SearchName&bn=$d'>$d</a>&nbsp &nbsp &nbsp";
			} else {
				$page .= "<a href='?bn=$d'>$d</a>&nbsp &nbsp &nbsp";
			}					            
		} 
	} else {
		$RecordeLimit = 10;
		$search = mysqli_query($db, "SELECT COUNT(project_id) as total FROM project");
		$SName = mysqli_fetch_array($search);
		
		$number_of_row = ceil($SName['total'] / 10);
		if (isset($_GET['bn']) && intval($_GET['bn']) <= $number_of_row && intval($_GET['bn'] != 0)) {
			$Skip = (intval($_GET["bn"]) * $RecordeLimit) - $RecordeLimit;
			$sql = mysqli_query($db, "SELECT * FROM project LIMIT $Skip, $RecordeLimit");
		} else {
			$sql = mysqli_query($db, "SELECT * FROM project LIMIT $RecordeLimit");
		}

		for ($i = 0; $i < $number_of_row; $i++) {
			$d = $i + 1;
		    $page .= "<a href='?bn=$d'>$d</a>&nbsp &nbsp &nbsp";
		}
	}
?>
<link rel="stylesheet" type="text/css" href="css/table-style.css" />
<link rel="stylesheet" type="text/css" href="css/table-style.css" />
<link rel="stylesheet" type="text/css" href="css/print-style.css" media="print">
<script type="text/javascript" src="js/jquery.basictable.min.js"></script>
<script type="text/javascript" src="js/jquery.basictable.min.js"></script>
<!-- Your additional styling and JavaScript for the table go here -->
<ol class="breadcrumb" style="margin: 10px 0px ! important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Project<i class="fa fa-angle-right"></i>Project View</li>
</ol>
<style>


</style>
<div class="validation-system" style="margin-top: 0;">	
	<div class="validation-form">
	 	<div>
			<div class="w3l-table-info">
			<h2>Project View</h2>
			<br>
		  	<form method="GET" action="#">
				<input style="float: right;" type="submit" name="searchview">
				<input style="float: right;" placeholder="Search" value="<?php echo (isset($SearchName)) ? $SearchName : ''; ?>" type="search-box" name="search"><br>
			</form>
			<form method="GET" action="deleteproject.php">
			<table id="table">
			<thead>
				<tr>
					<th style="text-transform: capitalize;">Project Name</th>
					<th style="text-transform: capitalize;">Description</th>
					<th style="text-transform: capitalize;">Start Date</th>
					<th style="text-transform: capitalize;">End Date</th>
					<th style="text-transform: capitalize; text-align: center;">Project File</th>
					<th style="text-transform: capitalize; text-align: center;">Status</th>
					<th style="text-transform: capitalize; text-align: center;">View Details</th>
					<th style="text-transform: capitalize; text-align: center;">Delete Project</th>
				</tr>
			</thead>
			<tbody>
			<?php while ($row = mysqli_fetch_assoc($sql)) { ?>
				<tr>
					<td><?php echo $row['project_name']; ?></td>
					<td><?php echo $row['description']; ?></td>
					<td><?php echo $row['start_date']; ?></td>
					<td><?php echo $row['end_date']; ?></td>
					<td style="text-align: center;"><a href="project_file/<?php echo $row['project_file']; ?>" target="_blank">View File</a></td>
					<td style="text-align: center;"><?php echo $row['status']; ?></td>
					<td style="text-align: center;"><a href="projectdetails.php?project_id=<?php echo $row['project_id']; ?>"><u>View</u></a></td>
					<td style="text-align: center; color: red;"><a href="deleteproject.php?project_id=<?php echo $row['project_id']; ?>" style="color: red;"><u>Delete</u></a></td>
				</tr>
			<?php } ?>
			</tbody>
			</table>
			<div><?php echo $page; ?></div>
			</div>  
		</div>
	 </div>
</div>
<script>
<script>
document.getElementById('printButton').addEventListener('click', function() {
    printTable();
});

function printTable() {
    var printContents = document.getElementById('table').outerHTML;
    var originalContents = document.body.innerHTML;

    document.body.innerHTML = printContents;
    window.print();

    document.body.innerHTML = originalContents;
}
</script>

<?php include('footer.php'); ?>
