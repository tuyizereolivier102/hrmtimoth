<?php
include('header.php');
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();

// Fetch the list of employees
$employeeQuery = mysqli_query($db, "SELECT EmployeeId, CONCAT(FirstName, ' ', LastName) AS FullName FROM employee");

if (isset($_POST['submitAttendance'])) {
    // Get the date and attendance records from the form
    $attendanceDate = mysqli_real_escape_string($db, $_POST['attendanceDate']);
    $currentTime = date('H:i'); // Get the current time in 24-hour format
    $m = date('m');

    // Check if attendance is already recorded for the selected date
    $existingAttendanceQuery = mysqli_query($db, "SELECT COUNT(*) AS count FROM attendance_records WHERE regdate = '$attendanceDate'");
    $existingAttendanceData = mysqli_fetch_assoc($existingAttendanceQuery);

    if ($existingAttendanceData['count'] > 0) {
        // Attendance is already recorded, display an error message
        echo "<script>window.alert('Attendance for the selected date already recorded. Please choose a different date.');</script>";
    } else {
        // Automatically mark users as absent if the current time is 17:00
        $autoAbsent = ($currentTime == '10:35');

        // Loop through each employee and record their attendance
        while ($employee = mysqli_fetch_assoc($employeeQuery)) {
            $empid = $employee['EmployeeId'];

            // Set attendance status based on the condition
            $attendance = $autoAbsent ? 'absent' : (isset($_POST['attendance'][$empid]) ? $_POST['attendance'][$empid] : 'absent');

            // Insert the attendance record for the employee on the given date
            mysqli_query($db, "INSERT INTO attendance_records (EmploiyeeId, attend, month, regdate) 
                                VALUES ('$empid', '$attendance', '$m','$attendanceDate')");
        }

        echo "<script>window.alert('Attendance recorded successfully.'); window.location='viewdate.php';</script>";
    }
}
?>

<ol class="breadcrumb" style="margin: 10px 0px !important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Record Attendance</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <form method="POST" action="" enctype="multipart/form-data">
            <!-- Hidden input for current date -->
            <input type="hidden" name="attendanceDate" value="<?php echo date('Y-m-d'); ?>">

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Employee ID</th>
                        <th>Employee Name</th>
                        <th>Attendance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Reset internal pointer
                    mysqli_data_seek($employeeQuery, 0);

                    while ($employee = mysqli_fetch_assoc($employeeQuery)) : ?>
                        <tr>
                            <td><?php echo $employee['EmployeeId']; ?></td>
                            <td><?php echo $employee['FullName']; ?></td>
                            <td>
                                <label class="radio-inline">
                                    <input type="radio" name="attendance[<?php echo $employee['EmployeeId']; ?>]" value="present" checked> Present
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="attendance[<?php echo $employee['EmployeeId']; ?>]" value="absent"> Absent
                                </label>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

            <div class="col-md-12 form-group">
                <button type="submit" name="submitAttendance" class="btn btn-primary">Record Attendance</button>
                <button type="reset" class="btn btn-default">Reset</button>
            </div>
            <div class="clearfix"></div>
        </form>
    </div>
</div>

<?php include('footer.php'); ?>
