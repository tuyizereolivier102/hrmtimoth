<?php include('header.php'); ?>
<?php
include_once('controller/connect.php');

$dbs = new database();
$db = $dbs->connection();
$roleId = "";
//$sql = mysqli_query($db,"select * from role ORDER BY Name");
error_reporting(0);
if (isset($_GET['roleedit'])) {
    $roleId = $_GET['roleedit'];
    $edit = mysqli_query($db, "select * from role where RoleId='$roleId'");
    $row = mysqli_fetch_assoc($edit);
    $roleName = $row['Name'];
    $salaryAmount = $row['Salary_amount'];
}

$page = "";
if (isset($_GET['searchrole'])) {
    $searchRoleName = $_GET['searchrole'];

    $RecordLimit = 5;
    $searchRole = mysqli_query($db, "select count(RoleId) as total from role where Name like '%" . $searchRoleName . "%'");
    $roleCount = mysqli_fetch_array($searchRole);

    $number_of_row = ceil($roleCount['total'] / 5);

    if (isset($_GET['bn']) && intval($_GET['bn']) <= $number_of_row && intval($_GET['bn'] != 0)) {
        $Skip = (intval($_GET["bn"]) * $RecordLimit) - $RecordLimit;
        $sql = mysqli_query($db, "select * from role where Name like '%" . $searchRoleName . "%' LIMIT $Skip,$RecordLimit ");
    } else {
        $sql = mysqli_query($db, "select * from role where Name like '%" . $searchRoleName . "%' LIMIT $RecordLimit ");

    }

    for ($i = 0; $i < $number_of_row; $i++) {
        $d = $i + 1;
        if (isset($_GET["searchrole"])) {
            $page .= "<a href='roleadd.php?searchrole=$searchRoleName&bn=$d'>$d</a>&nbsp &nbsp &nbsp";
        } else {
            $page .= "<a href='roleadd.php?bn=$d'>$d</a>&nbsp &nbsp &nbsp";
        }
    }
} else {
    $RecordLimit = 5;
    $searchRole = mysqli_query($db, "select count(RoleId) as total from role ");
    $roleCount = mysqli_fetch_array($searchRole);

    $number_of_row = ceil($roleCount['total'] / 5);
    if (isset($_GET['bn']) && intval($_GET['bn']) <= $number_of_row && intval($_GET['bn'] != 0)) {
        $Skip = (intval($_GET["bn"]) * $RecordLimit) - $RecordLimit;
        $sql = mysqli_query($db, "select * from role LIMIT $Skip,$RecordLimit");
    } else {
        $sql = mysqli_query($db, "select * from role LIMIT $RecordLimit");
    }

    for ($i = 0; $i < $number_of_row; $i++) {
        $d = $i + 1;
        $page .= "<a href='roleadd.php?bn=$d'>$d</a>&nbsp &nbsp &nbsp";
    }
}
?>
<link rel="stylesheet" type="text/css" href="css/table-style.css" />
<script type="text/javascript" src="js/jquery.basictable.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#table').basictable();
        // ... (other scripts)
    });
</script>

<ol class="breadcrumb" style="margin: 10px 0px ! important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Table Master<i
                class="fa fa-angle-right"></i>Roles
    </li>
</ol>

<div class="validation-system" style="margin-top: 0;display:flex">

    <div class="validation-form"
         style="overflow: auto; margin-right:20px; height: 450px; width: 49%; float: left;">
        <!---->
        <form method="POST"
              action="controller/ccity.php?roleedit=<?php echo isset($row['RoleId']) ? $row['RoleId'] : ''; ?>">
              <div class="vali-form-group">
    <h2>Add Role</h2>

    <div class="row">
        <div class="col-md-6">
            <label class="control-label">Role Name</label>
            <div class="input-group">
                <span class="input-group-addon">
                    <i class="fa fa-user" aria-hidden="true"></i>
                </span>
                <input type="text" name="roleName" required=""
                value="<?php echo $roleName; ?>"
                       placeholder="Role Name" class="form-control">
            </div>
        </div>
        <div class="col-md-6">
            <label class="control-label">Salary Amount</label>
            <div class="input-group">
                <span class="input-group-addon">
                    <i class="fa fa-money" aria-hidden="true"></i>
                </span>
                <input type="text" name="salaryAmount" required=""
                value="<?php echo $salaryAmount; ?>"
                       placeholder="Salary Amount" class="form-control">
            </div>
        </div>
    </div>

    <div class="clearfix"></div>
</div>

            <div class="col-md-12 form-group">
                <button type="submit" name="roleSubmit" class="btn btn-primary">Add</button>
                <button type="button" onclick="location.href = 'roleadd.php'"
                        class="btn btn-default">Reset
                </button>

            </div>
            <div class="clearfix"></div>
        </form>
        <!---->
    </div>
    <div class="validation-form" style="width: 49%; overflow: auto;">
        <div style="height: 396px;">
            <div class="w3l-table-info">
                <h2>Roles</h2>
                <br>

                <form method="GET" action="#">
                    <input style="float: right;" type="submit" name="searchrole">
                    <input style="float: right;" placeholder="Search..." type="search-box"
                           name="searchrole"
                           value="<?php echo(isset($_GET['searchrole'])) ? $_GET['searchrole'] : ""; ?>"><br>
                </form>
                <table id="table">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th style="width: 5000px;">Name</th>
                        <th style="text-align: center; width: 450px;">Salary Amount</th>
                        <th style="text-align: center; width: 450px;">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i = 1;
                    while ($row = mysqli_fetch_assoc($sql)) { ?>

                        <tr>
                            <td><?php if (isset($_GET['bn']) == 0) {
                                    echo $i;
                                } else {
                                    echo ($_GET['bn'] - 1) * 5 + $i;
                                }
                                $i++; ?></td>
                            <td><?php echo ucfirst($row['Name']); ?></td>
                            <td><?php echo $row['Salary_amount']; ?></td>
                            <td><a href="?roleedit=<?php echo $row['RoleId']; ?>"><i
                                            class="fa fa-pencil"
                                            aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a
                                        href="controller/ccity.php?roledelete=<?php echo $row['RoleId']; ?>"><i
                                            class="fa fa-trash-o"
                                            aria-hidden="true"></i></a></td>
                        </tr>

                    <?php } ?>
                    </tbody>
                </table>
                <div><?php echo $page; ?></div>
            </div>

        </div>
    </div>
</div>
<?php include('footer.php'); ?>
