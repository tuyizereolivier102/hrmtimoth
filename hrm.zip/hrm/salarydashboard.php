<?php include('header.php'); ?>

<?php
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();

// Sum Of Total Fixed salary
$TotalSalary = mysqli_query($db, "SELECT COALESCE(SUM(salary_amount), 0) AS total_amount FROM salaries;");
$TotalSalaryamount = mysqli_fetch_assoc($TotalSalary);

// Sum of Loans
$TotalLoan = mysqli_query($db, "SELECT COALESCE(SUM(amount), 0) AS total_amount1 FROM loans;");
$TotalLoanamount = mysqli_fetch_assoc($TotalLoan);

// Sum of Paid Loans
$TotalLoanpaid = mysqli_query($db, "SELECT COALESCE(SUM(amount_paid), 0) AS total FROM paid_loan;");
$TotalLoanpaidamount = mysqli_fetch_assoc($TotalLoanpaid);
// Sum of Payable
$Total = mysqli_query($db, "SELECT COALESCE(SUM(Salary_amount), 0) AS totals FROM employee;");
$Totals = mysqli_fetch_assoc($Total);
?>

<ol class="breadcrumb" style="margin: 10px 0px ! important;">
    <li class="breadcrumb-item" title="Salary Dashboard"><a href="home.php">Salary Dashboard</a></li>
</ol>
<!--four-grids here-->
    <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="panel panel-default bg-success dash-summary">
            <div class="panel-body">
                <a href="employee-loans.php">
                    <div class="icon">
                    <i class="fas fa-money-check-alt" aria-hidden="true"></i>
                    </div>
                    <div class="four-text">
                        <h3>Total Loan</h3>
                        <h4><?php echo (isset($TotalLoanamount['total_amount1'])) ? $TotalLoanamount['total_amount1'] : ""; ?></h4>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="panel panel-default bg-warning dash-summary">
            <div class="panel-body">
                <a href="employeeview.php">
                    <div class="icon">
                    <i class="fas fa-hand-holding-usd" aria-hidden="true"></i><br><i class="fas fa-check"></i>
                    </div>
                    <div class="four-text">
                        <h3>Salary Payable</h3>
                        <h4><?php echo (isset($Totals['totals'])) ? $Totals['totals'] : ""; ?></h4>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12">
        <div class="panel panel-default bg-danger dash-summary">
            <div class="panel-body">
                <a href="loans.php">
                    <div class="icon">
                    <i class="fas fa-handshake" aria-hidden="true"></i><br><i class="fas fa-check"></i>
                    </div>
                    <div class="four-text">
                        <h3>Paid Loan</h3>
                        <h4><?php echo (isset($TotalLoanpaidamount['total'])) ? $TotalLoanpaidamount['total'] : ""; ?></h4>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
</div>
<!-- Add this script at the end of your HTML body -->
<script>
  // Simple function to simulate a chat conversation
  function startChat() {
    var chatContainer = document.createElement('div');
    chatContainer.id = 'chat-container';
    document.body.appendChild(chatContainer);

    // Initial message
    addMessage("Hello! How can I assist you today?");

    // Add an event listener for user input (you can customize this part)
    document.addEventListener('keydown', function (event) {
      if (event.key === "Enter") {
        var userInput = event.target.value;
        addMessage("You: " + userInput);

        // You can analyze the user input and provide relevant responses here

        // For example, you can analyze if the user is asking for analysis
        if (userInput.toLowerCase().includes('analysis')) {
          addMessage("Sure, let me analyze the data for you...");
          // Add your analysis logic here

          // For demonstration purposes, let's just display a simple analysis
          addMessage("Analysis: The total salary is " + <?php echo $TotalSalaryamount['total_amount']; ?>);
        }

        // Clear the input field
        event.target.value = '';
      }
    });
  }

  // Function to add a message to the chat container
  function addMessage(message) {
    var chatContainer = document.getElementById('chat-container');
    var messageDiv = document.createElement('div');
    messageDiv.textContent = message;
    chatContainer.appendChild(messageDiv);
  }

  // Start the chat when the page is loaded
  document.addEventListener('DOMContentLoaded', startChat);
</script>

<!--//four-grids here-->

<?php include('footer.php'); ?>
