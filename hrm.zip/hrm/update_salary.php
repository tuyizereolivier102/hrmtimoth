<?php

include_once('controller/connect.php');
  
$dbs = new database();
$db=$dbs->connection();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['updateSalary'])) {
    // Get the selected employee ID
    $employeeId = mysqli_real_escape_string($db, $_POST['employeeId']);

    // Fetch employee details from the database based on the employee ID
    $employeeQuery = mysqli_query($db, "SELECT * FROM employee WHERE EmployeeId = '$employeeId'");
    $employee = mysqli_fetch_assoc($employeeQuery);

    // Fetch employee loans from the 'loans' table
    $loansQuery = mysqli_query($db, "SELECT SUM(amount) as totalLoans FROM loans WHERE EmployeeId = '$employeeId'");
    $loans = mysqli_fetch_assoc($loansQuery);

    // Fetch employee paid loans from the 'paid_loan' table
    $paidLoansQuery = mysqli_query($db, "SELECT SUM(pl.amount_paid) as totalPaidLoans 
                                          FROM paid_loan pl
                                          JOIN loans l ON pl.loan_id = l.loan_id
                                          WHERE l.EmployeeId = '$employeeId'");
    $paidLoans = mysqli_fetch_assoc($paidLoansQuery);

    // Fetch total attendance days, present days, and absent days for the selected employee
    $attendanceQuery = mysqli_query($db, "SELECT COUNT(*) as totalAttendance, 
                                                 SUM(CASE WHEN attend = 'Present' THEN 1 ELSE 0 END) as presentDays,
                                                 SUM(CASE WHEN attend = 'Absent' THEN 1 ELSE 0 END) as absentDays
                                          FROM attendance_records 
                                          WHERE EmploiyeeId = '$employeeId'");
    $attendance = mysqli_fetch_assoc($attendanceQuery);

    // Fetch overtime details for the selected employee
    $overtimeQuery = mysqli_query($db, "SELECT SUM(overtime_hours) as totalOvertimeHours
                                         FROM overtime
                                         WHERE EmploiyeeId = '$employeeId'");
    $overtime = mysqli_fetch_assoc($overtimeQuery);

    // Calculate remaining loan
    $remainingLoan = $loans['totalLoans'] - $paidLoans['totalPaidLoans'];

    // Calculate the daily salary
    $dailySalary = $employee['Salary_amount'] / 30; // Assuming 30 days in a month

    // Calculate the possible salary
    $possibleSalary = $dailySalary * $attendance['totalAttendance'] - $loans['totalLoans'] + $paidLoans['totalPaidLoans'];

    // Update the salary_amount in the employee table
    $updateSalaryQuery = "UPDATE employee SET Salary_amount = '$possibleSalary' WHERE EmployeeId = '$employeeId'";
    mysqli_query($db, $updateSalaryQuery);

    // Display a success message
    echo "<p><strong>Salary updated successfully!</strong></p>";

    // Redirect to the previous page or wherever you want after updating the salary
    header("Location: ".$_SERVER['HTTP_REFERER']);
    exit();
} else {
    // If the form is not submitted or the updateSalary button is not clicked, handle the case accordingly
    echo "Form not submitted or invalid request";
}
?>
