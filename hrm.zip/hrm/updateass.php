<?php
$co=mysqli_connect("localhost","root","","hrm_db");
    $id = $_GET['assign_id'];
    $deleteQuery = mysqli_query($co,"UPDATE assign_project SET status='Complete' WHERE assign_id='$id'");
    if($deleteQuery) {
        echo "<script>window.alert('Updated'); window.location='viewassignedproject.php';</script>";
        exit();
    } else {
        echo "Error deleting record";
    }
?>