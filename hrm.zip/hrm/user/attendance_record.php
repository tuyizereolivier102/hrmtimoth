<?php include('header.php'); ?>

<?php
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();

if (isset($_POST['submitUser'])) {
    $firstName = mysqli_real_escape_string($db, $_POST['firstName']);
    $lastName = mysqli_real_escape_string($db, $_POST['lastName']);
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password for security

    // Check if the email is already registered
    $checkEmailQuery = mysqli_query($db, "SELECT * FROM users WHERE email = '$email'");
    if (mysqli_num_rows($checkEmailQuery) > 0) {
        echo "<script>window.alert('Email is already registered. Please choose another email.'); window.location='../admin/dashboard.php';</script>";
        exit();
    }

    // Insert the new user into the database
    mysqli_query($db, "INSERT INTO users (firstName, lastName, email, password) 
                      VALUES ('$firstName', '$lastName', '$email', '$password')");

    echo "<script>window.alert('User created successfully.'); window.location='../admin/dashboard.php';</script>";
}
?>

<ol class="breadcrumb" style="margin: 10px 0px !important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Create User</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <form method="POST" action="" enctype="multipart/form-data">
            <div class="col-md-4 control-label">
                <label class="control-label">First Name:</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-user" aria-hidden="true"></i>
                    </span>
                    <input type="text" name="firstName" required>
                </div>
            </div>

            <div class="col-md-4 control-label">
                <label class="control-label">Last Name:</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-user" aria-hidden="true"></i>
                    </span>
                    <input type="text" name="lastName" required>
                </div>
            </div>

            <div class="col-md-4 control-label">
                <label class="control-label">Email:</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-envelope" aria-hidden="true"></i>
                    </span>
                    <input type="email" name="email" required>
                </div>
            </div>

            <div class="col-md-4 control-label">
                <label class="control-label">Password:</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-lock" aria-hidden="true"></i>
                    </span>
                    <input type="password" name="password" required>
                </div>
            </div>

            <div class="col-md-12 form-group">
                <button type="submit" name="submitUser" class="btn btn-primary">Create User</button>
                <button type="reset" class="btn btn-default">Reset</button>
            </div>
            <div class="clearfix"></div>
        </form>
    </div>
</div>

<?php include('footer.php'); ?>
