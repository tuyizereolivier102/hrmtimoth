<?php
include('userheader.php');

require_once('../controller/connect1.php');  // Assuming connect.php handles database connection

// Get the employee ID from the session (replace with your actual session variable)
$employeeEmail = $_SESSION['User']['Email'];

// Prepared statement to prevent SQL injection
$employeeQuery = $db->prepare("SELECT * FROM employee WHERE Email=?");
$employeeQuery->bind_param("s", $employeeEmail);
$employeeQuery->execute();
$employeeResult = $employeeQuery->get_result();

if ($employeeResult->num_rows > 0) {
    $employeeRow = $employeeResult->fetch_assoc();
    $employeeId = $employeeRow['EmployeeId'];

    // Fetch assigned projects based on their status from the project table
    $projectsQuery = $db->prepare("SELECT ap.*, e.*, p.project_name FROM assign_project ap
                                    JOIN employee e ON ap.employee_id = e.EmployeeId
                                    JOIN project p ON ap.project_id = p.project_id
                                    WHERE ap.employee_id=? AND ap.status='Complete'");
    $projectsQuery->bind_param("i", $employeeId);
    $projectsQuery->execute();
    $projectsResult = $projectsQuery->get_result();

    // Check if there are complete projects before trying to fetch data
    if ($projectsResult->num_rows > 0) {
        ?>

        <div class="s-12 l-6">
            <div class="validation-form">
                <div class="w3l-table-info">
                    <h2>Assigned Complete Projects</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Names</th>
                                <th>Project Name</th>
                                <th>Assignment Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($project = $projectsResult->fetch_assoc()) { ?>
                                <tr>
                                    <td><?php echo $project['FirstName'] . ' ' . $project['LastName']; ?></td>
                                    <td><?php echo $project['project_name']; ?></td>
                                    <td><?php echo $project['assignment_date']; ?></td>
                                    <td>Complete</td> <!-- Assuming status is always 'Complete' in the project table -->
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php
    } else {
        // Display a message indicating that there are no complete projects
        echo '<div class="s-12 l-6"><p>No complete projects.</p></div>';
    }

    // Close the prepared statement
    $projectsQuery->close();
}

// Close the connection
$db->close();

include('userfooter.php');
?>
