<?php
include('userheader.php');

require_once('../controller/connect1.php');  // Assuming connect.php handles database connection

// Get the employee ID from the session (replace with your actual session variable)
$employeeEmail = $_SESSION['User']['Email'];

// Prepared statement to prevent SQL injection
$employeeQuery = $db->prepare("SELECT * FROM employee WHERE Email=?");
$employeeQuery->bind_param("s", $employeeEmail);
$employeeQuery->execute();
$employeeResult = $employeeQuery->get_result();

if ($employeeResult->num_rows > 0) {
    $employeeRow = $employeeResult->fetch_assoc();
    $employeeId = $employeeRow['EmployeeId'];

    // Fetch assigned projects using a prepared statement
    $assignedProjectsQuery = $db->prepare("SELECT ap.*, e.*, p.project_name FROM assign_project ap
                                          JOIN employee e ON ap.employee_id = e.EmployeeId
                                          JOIN project p ON ap.project_id = p.project_id
                                          WHERE ap.employee_id=?");
    $assignedProjectsQuery->bind_param("i", $employeeId);
    $assignedProjectsQuery->execute();
    $assignedProjectsResult = $assignedProjectsQuery->get_result();

    ?>

    <div class="s-12 l-6">
        <div class="validation-form">
            <div class="w3l-table-info">
                <h2>Assigned Projects</h2>
                <table>
                    <thead>
                        <tr><th>Names</th>
                            <th>Project Name</th>
                            <th>Assignment Date</th>
                            <th>Status</th>
                            <th>Assigned By</th>
                            </tr>
                    </thead>
                    <tbody>
                        <?php while ($project = $assignedProjectsResult->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $project['FirstName'] . ' ' . $project['LastName']; ?></td>
                            <td><?php echo $project['project_name']; ?></td>
                            <td><?php echo $project['assignment_date']; ?></td>
                            <td><?php echo $project['status']; ?></td>
                            <td><?php echo $project['assignedby']; ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php
}

include('userfooter.php');
?>
