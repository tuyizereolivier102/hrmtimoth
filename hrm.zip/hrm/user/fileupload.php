<?php
include('userheader.php');
include_once('../controller/connect.php');
error_reporting(0);
$dbs = new database();
$db = $dbs->connection();

$empid = $_SESSION['User']['EmployeeId'];

if (!isset($_SESSION['User']['EmployeeId'])) {
    header("Location: index.php");
    exit();
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $file_name = $_POST["file"];
    $uploaded_by = $_SESSION['User']['Email'];

    // Check if a file is selected
    if(isset($_FILES['payment_receipt']) && $_FILES['payment_receipt']['error'] == 0) {
        $target_dir = "../uploads/"; // Change this directory path accordingly
        $target_file = $target_dir . basename($_FILES["payment_receipt"]["name"]);
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if the file is a PDF
        if($file_type == "pdf") {
            // Move the uploaded file to the target directory
            if (move_uploaded_file($_FILES["payment_receipt"]["tmp_name"], $target_file)) {
                // Insert only the file name into the file_uploads table
                $insertQuery = "INSERT INTO file_uploads (file_name, file_description, uploaded_by) 
                                VALUES ('$file_name', '" . basename($_FILES["payment_receipt"]["name"]) . "', '$uploaded_by')";
                $result = mysqli_query($db, $insertQuery);

                if ($result) {
                    
                    echo "<script>window.alert('File uploaded successfully!');window.location='home.php';</script>";
                } else {
                    echo "<p style='color: red;'>Error uploading file. Please try again.</p>";
                    header("Location: home.php");
                }
            } else {
                echo "<p style='color: red;'>Error moving the uploaded file to the target directory.</p>";
            }
        } else {
            echo "<p style='color: red;'>Only PDF files are allowed.</p>";
        }
    } else {
        echo "<p style='color: red;'>Please select a PDF file to upload.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>File Upload</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <!-- Add your styles and scripts here -->
</head>
<body>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        text-align: center;
        padding: 50px;
    }

    .loan-payment-form-container {
        max-width: 400px;
        margin: 0 auto;
        background-color: #ffffff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    input, button, select {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        box-sizing: border-box;
    }

    button {
        background-color: #4caf50;
        color: #ffffff;
        border: none;
        border-radius: 3px;
        cursor: pointer;
    }

    form {
        display: flex;
        flex-direction: column;
        align-items: center;
    }
</style>

<div class="loan-payment-form-container">
    <h2>File Upload</h2>
    <form action="" method="post" enctype="multipart/form-data">
       <label>Select Document/File Name:</label>
        <select name="file" required>
            <option disabled selected>Select Name</option>
            <option value="loan">Loan</option>
            <option value="project">Project</option>
            <option value="leave">Leave</option>
        </select>
        <label>Document(PDF only):</label>
        <input type="file" name="payment_receipt" accept=".pdf">
        <button type="submit">Upload</button>
    </form>
</div>
<?php include('userfooter.php'); ?>
</body>
</html>
