<?php include('userheader.php'); ?>
<style>
    .dash-summary {
        display: flex;
        justify-content: space-between;
        width: 83%;
        margin: 20px auto;
    }

    .dash-panel {
        border: 1px solid #f0efef;
        width: 48%;
        padding: 1em 1em;
        box-shadow: 2px 2px 7px #c8c8c8;
    }

    .announcement-section {
        margin: 20px auto;
        width: 70%;
        display: flex;
        flex-wrap: wrap;
    }

    .announcement {
        border: 1px solid #ddd;
        padding: 15px;
        margin: 10px;
        width: calc(33.33% - 20    px); /* Adjust the width as needed */
        box-sizing: border-box;
        background-color: #f9f9f9;
        border-color: darkblue;
    }

    .announcement h3 {
        margin-top: 0;
        text-decoration: underline;
        color: red;
    }

    .announcement p {
        margin-bottom: 5px;
        color: black;
    }
    .welcome h1{
            color: darkblue;
    }
    
</style>

<?php
include_once('../controller/connect.php');
$dbs = new database();
$db = $dbs->connection();
$pending = 0;
$accepted = 0;
$EmpId = $_SESSION['User']['EmployeeId'];
$pending_sql = "SELECT Detail_Id FROM `leavedetails` where EmpId= '{$EmpId}' and `LeaveStatus` = 'Pending'";
$pending_qry = mysqli_query($db, $pending_sql);
$pending = $pending_qry->num_rows;

$accepted_sql = "SELECT Detail_Id FROM `leavedetails` where EmpId= '{$EmpId}' and `LeaveStatus` = 'Accept'";
$accepted_qry = mysqli_query($db, $accepted_sql);
$accepted = $accepted_qry->num_rows;

// Fetch announcements with valid dates
$currentDate = date('Y-m-d');
$announcementsQuery = mysqli_query($db, "SELECT * FROM announcements WHERE expiration_date >= '{$currentDate}'");

?>
<div class="welcome">
    <h1>Welcome to Your Dashboard</h1>
</div>
<div class="s-12 dash-summary">
    <div class="dash-panel">
        <h3>No. of Pending Applications</h3>
        <h4 align="right"><?= number_format($pending) ?></h4>
    </div>
    <div class="dash-panel">
        <h3>No. of Accepted Applications</h3>
        <h4 align="right"><?= number_format($accepted) ?></h4>
    </div>
</div>

<!-- Display Announcements -->
<h2>Announcements</h2><br>
<div class="s-12 announcement-section">
    
    <?php
    while ($row = mysqli_fetch_assoc($announcementsQuery)) {
        echo "<div class='announcement'>
                <u><h3>{$row['title']}</h3></u>
                <p>{$row['content']}</p>
              </div>";
    }
    ?>
</div>

<?php include('userfooter.php'); ?>
