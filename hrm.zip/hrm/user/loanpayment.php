<?php
include('userheader.php');
include_once('../controller/connect.php');

$dbs = new database();
$db = $dbs->connection();

$empid = $_SESSION['User']['EmployeeId'];

if (!isset($_SESSION['User']['EmployeeId'])) {
    header("Location: index.php");
    exit();
}

// Fetch all approved loans associated with the employee
$loansQuery = mysqli_query($db, "SELECT * FROM loans WHERE EmployeeId = $empid AND LoanStatus = 'Approved'");

// Fetch total amount paid for approved loans associated with the employee
$paidAmountQuery = mysqli_query($db, "SELECT SUM(pl.amount_paid) AS paidAmount
                                       FROM paid_loan pl
                                       INNER JOIN loans l ON pl.loan_id = l.loan_id
                                       WHERE l.EmployeeId = $empid AND l.LoanStatus = 'Approved'");

$paidAmountResult = mysqli_fetch_assoc($paidAmountQuery);
$paidAmount = $paidAmountResult['paidAmount'];

// Fetch total loan amount based on the employee's approved loans
$totalLoanAmountQuery = mysqli_query($db, "SELECT SUM(amount) AS totalLoanAmount FROM loans WHERE EmployeeId = $empid AND LoanStatus = 'Approved'");
$totalLoanAmountResult = mysqli_fetch_assoc($totalLoanAmountQuery);
$totalLoanAmount = $totalLoanAmountResult['totalLoanAmount'];

// Calculate remaining balance
$remainingBalance = $totalLoanAmount - $paidAmount;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $loanId = $_POST["loan_id"];
    $paymentAmount = $_POST["payment_amount"];
    $paymentDate = date("Y-m-d H:i:s");

    // Check if the selected loan has already been fully paid
    $checkPaidQuery = mysqli_query($db, "SELECT SUM(amount_paid) AS totalPaid FROM paid_loan WHERE loan_id = $loanId");
    $checkPaidResult = mysqli_fetch_assoc($checkPaidQuery);
    $totalPaid = $checkPaidResult['totalPaid'];

    if ($totalPaid >= $totalLoanAmount) {
        $error_message = "This loan has already been fully paid. Please select another loan.";
    } else {
        // Fetch details of the selected loan
        $selectedLoanQuery = mysqli_query($db, "SELECT * FROM loans WHERE loan_id = $loanId");
        $loan = mysqli_fetch_assoc($selectedLoanQuery);

        // Insert loan payment record into the paid_loan table
        $stmt = $db->prepare("INSERT INTO paid_loan (loan_id, payment_date, amount_paid) VALUES (?, ?, ?)");
        $stmt->bind_param("isd", $loanId, $paymentDate, $paymentAmount);

        if ($stmt->execute()) {
            $success_message = "Loan payment recorded successfully!";
        } else {
            $error_message = "Error: " . $db->error;
        }

        $stmt->close();
    }
}

$db->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Loan Payment Form</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <!-- Add your styles and scripts here -->
</head>
<body>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        text-align: center;
        padding: 50px;
    }

    .loan-payment-form-container {
        max-width: 400px;
        margin: 0 auto;
        background-color: #ffffff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    input, button, select {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        box-sizing: border-box;
    }

    button {
        background-color: #4caf50;
        color: #ffffff;
        border: none;
        border-radius: 3px;
        cursor: pointer;
    }

    form {
        display: flex;
        flex-direction: column;
        align-items: center;
    }
</style>

<div class="loan-payment-form-container">
    <h2>Loan Payment Form</h2>

    <?php
    // Display success or error messages, if any
    if (isset($success_message)) {
        echo "<p style='color: green;'>$success_message</p>";
    } elseif (isset($error_message)) {
        echo "<p style='color: red;'>$error_message</p>";
    }
    ?>

    <form action="loanpayment.php" method="post">
        <label>Select Loan:</label>
        <select name="loan_id" required>
            <option value="" disabled selected>Select a loan</option>
            <?php while ($loan = mysqli_fetch_assoc($loansQuery)) { ?>
                <option value="<?php echo $loan['loan_id']; ?>"><?php echo "Loan ID: " . $loan['loan_id'] . " - Amount: $" . $loan['amount']; ?></option>
            <?php } ?>
        </select>
        <label>Payment Amount:</label>
        <input type="number" name="payment_amount" step="0.01" required>
        <button type="submit">Record Payment</button>
    </form>

    <?php if ($remainingBalance > 0) { ?>
        <h3>Total Amount Paid for Approved Loans: $<?php echo $paidAmount; ?></h3>
        <h3>Remaining Balance: $<?php echo $remainingBalance; ?></h3>
    <?php } else { ?>
        <p>All approved loans have been fully paid. No further payments are required.</p>
    <?php } ?>
</div>

<script>
    // Set the selected loan ID in a hidden input field on change
    $('select[name="loan_id"]').on('change', function () {
        $('#loan_id').val($(this).val());
    });
</script>

<?php include('userfooter.php'); ?>
</body>
</html>
