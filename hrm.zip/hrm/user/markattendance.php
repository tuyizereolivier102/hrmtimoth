<?php
include('userheader.php'); 
include_once('../controller/connect.php');

$dbs = new database();
$db = $dbs->connection();

$empid = $_SESSION['User']['EmployeeId'];

if (!isset($_SESSION['User']['EmployeeId'])) {
    header("Location: index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employeeId = $_SESSION['User']['EmployeeId']; // Use the correct variable name
    $status = $_POST["status"];
    $attendance_time = date("Y-m-d H:i:s");
    $regdate = date("Y-m-d H:i:s");

    // Check if attendance is already recorded for today
    $checkQuery = "SELECT * FROM attendance_records WHERE EmploiyeeId = '$employeeId' AND DATE(att_time) = CURDATE()";
    $result = $db->query($checkQuery);

    if ($result->num_rows > 0) {
        $error_message = "Attendance already recorded for today!";
    } else {
        $employeeId = $_SESSION['User']['EmployeeId'];
        // Insert attendance record into the database
        $stmt = $db->prepare("INSERT INTO attendance_records (EmploiyeeId, attend, att_time, regdate) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $employeeId, $status, $attendance_time, $regdate); // Use $employeeId

        if ($stmt->execute()) {
            $success_message = "Attendance recorded successfully!";
        } else {
            $error_message = "Error: " . $db->error;
        }

        $stmt->close();
    }
}

$db->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Hrm Attendance Form</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <!-- Add your styles and scripts here -->
</head>
<body>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        text-align: center;
        padding: 50px;
    }

    .attendance-form-container {
        max-width: 400px;
        margin: 0 auto;
        background-color: #ffffff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    input, button {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        box-sizing: border-box;
    }

    button {
        background-color: #4caf50;
        color: #ffffff;
        border: none;
        border-radius: 3px;
        cursor: pointer;
    }

    form {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    #countdown {
        margin-top: 10px;
        font-weight: bold;
        display: block; /* Ensure the countdown is visible */
    }

    .attendance-link {
        background-color: #3498db; /* Choose your desired background color */
        padding: 10px;
        text-align: center;
    }

    .attendance-link a {
        color: #ffffff; /* Choose your desired text color */
        text-decoration: none;
        font-weight: bold;
        font-size: 16px;
    }

    .attendance-link a:hover {
        color: #ffffff; /* Change color on hover if desired */
        text-decoration: underline;
    }
</style>

<div class="attendance-form-container">
    <h2>Attendance Form</h2>

    <?php
    // Display success or error messages, if any
    if (isset($success_message)) {
        echo "<p style='color: green;'>$success_message</p>";
    } elseif (isset($error_message)) {
        echo "<p style='color: red;'>$error_message</p>";
    }
    ?>

    <form action="markattendance.php" method="post">
        <label>Status:</label>
        Present<input type="radio" name="status" value="Present" checked>
        Absent<input type="radio" name="status" value="Absent">
        <div id="countdown" style="color:red;"></div>
        <button type="submit">Record Attendance</button>
    </form>
    <div class="attendance-link">
        <a href="view.php">View Attendance Records</a>
    </div>
    <div id="countdown"></div>
</div>

<script>
    $(document).ready(function () {
        var startTime = new Date();
        startTime.setHours(8, 0, 0); // Set start time to 8:00 AM
        var endTime = new Date();
        endTime.setHours(17, 30, 0); // Set end time to 5:30 PM

        var submitButton = $('button[type="submit"]');
        var countdownContainer = $('#countdown'); // Fix the ID here

        function updateButtonVisibility() {
            var currentTime = new Date();

            // Check if the current time is between the start and end times
            if (currentTime >= startTime && currentTime <= endTime) {
                submitButton.show();
                countdownContainer.show();
                // Calculate remaining time in minutes and seconds
                var timeRemaining = endTime - currentTime;
                var hours = Math.floor(timeRemaining / (1000 * 60 * 60));
                var minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((timeRemaining % (1000 * 60)) / 1000);

                countdownContainer.text('Time remaining Record Yourself: ' + hours + 'h ' + minutes + 'm ' + seconds + 's');
            } else {
                submitButton.hide();
                countdownContainer.show();

                // Calculate remaining time in minutes and seconds
                var timeRemaining = endTime - currentTime;
                var hours = Math.floor(timeRemaining / (1000 * 60 * 60));
                var minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((timeRemaining % (1000 * 60)) / 1000);

                countdownContainer.text('Time remaining: ' + hours + 'h ' + minutes + 'm ' + seconds + 's');
            }
        }

        // Update button visibility every second
        setInterval(updateButtonVisibility, 1000);

        // Initial call to set the initial state
        updateButtonVisibility();
    });
</script>

<?php include('userfooter.php'); ?>
