<?php
include('userheader.php'); 
include_once('../controller/connect.php');

$dbs = new database();
$db = $dbs->connection();

$empid = $_SESSION['User']['EmployeeId'];

if (!isset($_SESSION['User']['EmployeeId'])) {
    header("Location: index.php");
    exit();
}

// Define possible loan purposes
$loanPurposes = array("Home Improvement", "Education", "Medical Expenses", "Debt Consolidation", "Other");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employeeId = $_SESSION['User']['EmployeeId'];
    $amount = $_POST["amount"];
    $purpose = $_POST["purpose"];
    $loanStatus = "Pending"; // Set the initial status as pending
    $requestDate = date("Y-m-d H:i:s");

    // Insert loan request into the loans table
    $stmt = $db->prepare("INSERT INTO loans (EmployeeId, amount, LoanStatus, purpose, request_date) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("idsss", $employeeId, $amount, $loanStatus, $purpose, $requestDate);

    if ($stmt->execute()) {
        $success_message = "Loan request submitted successfully!";
    } else {
        $error_message = "Error: " . $db->error;
    }

    $stmt->close();
}

$db->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Loan Request Form</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <!-- Add your styles and scripts here -->
</head>
<body>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        text-align: center;
        padding: 50px;
    }

    .loan-form-container {
        max-width: 400px;
        margin: 0 auto;
        background-color: #ffffff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    input, select, button {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        box-sizing: border-box;
    }

    button {
        background-color: #4caf50;
        color: #ffffff;
        border: none;
        border-radius: 3px;
        cursor: pointer;
    }

    form {
        display: flex;
        flex-direction: column;
        align-items: center;
    }
</style>

<div class="loan-form-container">
    <h2>Loan Request Form</h2>

    <?php
    // Display success or error messages, if any
    if (isset($success_message)) {
        echo "<p style='color: green;'>$success_message</p>";
    } elseif (isset($error_message)) {
        echo "<p style='color: red;'>$error_message</p>";
    }
    ?>

    <form action="requestloan.php" method="post">
        <label for="amount">Loan Amount:</label>
        <input type="text" name="amount" required>

        <label for="purpose">Loan Purpose:</label>
        <select name="purpose" required>
            <option value="" disabled selected>Select a purpose</option>
            <?php
            // Populate loan purposes dropdown
            foreach ($loanPurposes as $loanPurpose) {
                echo "<option value=\"$loanPurpose\">$loanPurpose</option>";
            }
            ?>
        </select>

        <button type="submit">Submit Loan Request</button>
       <a href="viewloanrequest.php">View Loan Request</a>
    </form>
</div>

<?php include('userfooter.php'); ?>
