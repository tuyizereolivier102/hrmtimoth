<?php include('userheader.php'); ?>
<?php
include_once('../controller/connect.php');

$dbs = new database();
$db = $dbs->connection();

$empid = $_SESSION['User']['EmployeeId'];

// Handle date search
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $search_date = $_POST["search_date"];
    $attendance_records = mysqli_query($db, "SELECT * FROM attendance_records WHERE EmploiyeeId = '$empid' AND DATE(att_time) = '$search_date'");
} else {
    // Fetch all attendance records if no search is performed
    $attendance_records = mysqli_query($db, "SELECT * FROM attendance_records WHERE EmploiyeeId = '$empid'");
}
?>

<div class="s-12 l-10">
    <h1 style="color: #858282;">View Attendance Records</h1>
    <hr>
    <div class="clearfix"></div>

    <!-- Date Search Form -->
    <form action="view.php" method="post" style="margin-bottom: 20px;">
        <label for="search_date">Search by Date:</label>
        <input type="date" id="search_date" name="search_date" required>
        <button type="submit">Search</button>
    </form>

    <table class="attendance-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Attendance Status</th>
                <th>Attendance Time</th>
                <th>Registration Date</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($attendance_records)) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['attend']; ?></td>
                    <td><?php echo $row['att_time']; ?></td>
                    <td><?php echo $row['regdate']; ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<style>
    .attendance-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .attendance-table th,
    .attendance-table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    .attendance-table th {
        background-color: #858282;
        color: white;
        font-weight: bold;
    }

    .attendance-table tr:hover {
        background-color: #f5f5f5;
    }

    /* Style for the search form */
    form {
        display: flex;
        gap: 10px;
    }

    label {
        line-height: 30px;
    }
</style>

<?php include('userfooter.php'); ?>
