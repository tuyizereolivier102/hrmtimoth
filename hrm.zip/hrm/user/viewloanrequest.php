<?php
include('userheader.php');
include_once('../controller/connect.php');

$dbs = new database();
$db = $dbs->connection();

$empid = $_SESSION['User']['EmployeeId'];

if (!isset($_SESSION['User']['EmployeeId'])) {
    header("Location: index.php");
    exit();
}

// Fetch loan requests for the logged-in employee
$loanQuery = "SELECT * FROM loans WHERE EmployeeId = '$empid'";
$loanResult = $db->query($loanQuery);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Loan Requests</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <!-- Add your styles and scripts here -->
</head>
<body>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        text-align: center;
        padding: 50px;
    }

    .loan-list-container {
        max-width: 600px;
        margin: 0 auto;
        background-color: #ffffff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #858282;
        color: white;
        font-weight: bold;
    }

    tr:hover {
        background-color: #f5f5f5;
    }
</style>

<div class="loan-list-container">
    <h2>View Loan Requests</h2>

    <?php
    // Display loan requests in a table
    if ($loanResult->num_rows > 0) {
        echo "<table>
                <thead>
                    <tr>
                        <th>Loan ID</th>
                        <th>Loan Amount</th>
                        <th>Loan Purpose</th>
                        <th>Loan Status</th>
                        <th>Request Date</th>
                    </tr>
                </thead>
                <tbody>";

        while ($loanRow = $loanResult->fetch_assoc()) {
            echo "<tr>
                    <td>{$loanRow['loan_id']}</td>
                    <td>{$loanRow['amount']}</td>
                    <td>{$loanRow['purpose']}</td>
                    <td>{$loanRow['LoanStatus']}</td>
                    <td>{$loanRow['request_date']}</td>
                </tr>";
        }

        echo "</tbody></table>";
    } else {
        echo "<p>No loan requests found.</p>";
    }
    ?>
</div>

<?php include('userfooter.php'); ?>
