<?php include('header.php'); ?>

<?php
include_once('controller/connect.php');

$dbs = new database();
$db = $dbs->connection();

// Assuming you have a function to fetch assigned projects with search functionality
$searchKeyword = isset($_GET['search']) ? $_GET['search'] : '';
$assignedProjects = fetchAssignedProjects($db, $searchKeyword);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="css/table-style.css" />
    <script type="text/javascript" src="js/jquery.basictable.min.js"></script>
</head>

<style>
    /* projectdetails-style.css */

</style>

<body>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <div>
            <div class="w3l-table-info">
                <h2>View Assigned Projects</h2>

                <!-- Search Box -->
                <form method="GET" action="viewassignedproject.php">
                    <input type="text" name="search" placeholder="Search..." value="<?php echo htmlentities($searchKeyword); ?>">
                    <button type="submit">Search</button>
                </form>
                <table>
        <thead>
            <tr>
                <th>Employee</th>
                <th>Employee ID</th>
                <th>Project</th>
                <th>Assignment Date</th>
                <th>Status</th>
                <th>Assigned By</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($assignedProjects as $assignedProject) : ?>
                <tr>
                    <td><?php echo $assignedProject['employee_name']; ?></td>
                    <td><?php echo $assignedProject['empid']; ?></td>
                    <td><?php echo $assignedProject['project_name']; ?></td>
                    <td><?php echo $assignedProject['assignment_date']; ?></td>
                    <td><?php echo $assignedProject['status']; ?></td>
                    <td><?php echo $assignedProject['assignedby']; ?></td>
                    <td>
                   <input type="hidden" name="assign_id">
                        <a href="delete.php?assign_id=<?php echo $assignedProject['assign_id']; ?>" onclick="return confirm('Are you sure you want to delete this record?')" class="btn-delete" style="color: red;"><i class="fas fa-trash-alt" style="color: red;" ></i><b style="color: red;background-color:white"> Delete</b></a>
                        <a href="updateass.php?assign_id=<?php echo $assignedProject['assign_id']; ?>" onclick="return confirm('Are you sure you want to Update Status?')" class="btn-delete" style="color: red;"><i class="fas fa-check" style="color: blue;" ></i><b style="color: blue;background-color:white"> Completed</b></a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>

</body>
</html>
