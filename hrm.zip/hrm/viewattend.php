<?php
include('header.php');

include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();

$attendanceData = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $employeeId = $_POST['empid'];
    $selectedMonth = $_POST['selectedMonth'];

    // Fetch all attendance records for the selected employee and month
    $attendanceQuery = mysqli_query($db, "SELECT * FROM attendance_records WHERE EmploiyeeId = '$employeeId' AND month = '$selectedMonth'");
    
    // Store attendance data in an array
    while ($row = mysqli_fetch_assoc($attendanceQuery)) {
        $attendanceData[] = $row;
    }
}

?>

<ol class="breadcrumb" style="margin: 10px 0px !important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Attendance Check</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <form method="POST" action="viewmonthlyattendance.php" enctype="multipart/form-data" id="checkAttendanceForm">

            <!-- Other form fields -->

            <!-- Employee ID -->
            <div class="col-md-4 control-label">
                <label class="control-label">Employee</label>
                <div class="input-group">             
                    <span class="input-group-addon">
                        <i class="fa fa-user" aria-hidden="true"></i>
                    </span>
                    <select name="empid" title="Employee" class="form-control" required>
                        <option value="">-- Select Employee --</option>
                        <?php 
                            $employeeQuery = mysqli_query($db, "SELECT EmployeeId, CONCAT(FirstName, ' ', LastName) AS FullName FROM employee");
                            while ($row = mysqli_fetch_assoc($employeeQuery)) {
                                $selected = ($employeeId == $row['EmployeeId']) ? 'selected' : '';
                                echo "<option value='{$row['EmployeeId']}' $selected>{$row['FullName']}-->{$row['EmployeeId']}</option>";
                            }
                        ?>
                    </select>
                </div>
            </div>

            <!-- Select Month -->
            <div class="col-md-4 control-label">
                <label class="control-label">Month</label>
                <div class="input-group">             
                    <span class="input-group-addon">
                        <i class="fa fa-calendar" aria-hidden="true"></i>
                    </span>
                    <select name="selectedMonth" class="form-control" required>
                        <option value="">-- Select Month --</option>
                        <?php 
                            // Associative array to map month numbers to names
                            $monthNames = [
                                '01' => 'January',
                                '02' => 'February',
                                '03' => 'March',
                                '04' => 'April',
                                '05' => 'May',
                                '06' => 'June',
                                '07' => 'July',
                                '08' => 'August',
                                '09' => 'September',
                                '10' => 'October',
                                '11' => 'November',
                                '12' => 'December'
                            ];

                            // Fetch distinct months from attendance_records
                            $monthsQuery = mysqli_query($db, "SELECT DISTINCT month FROM attendance_records");
                            while ($month = mysqli_fetch_assoc($monthsQuery)) {
                                $selected = ($selectedMonth == $month['month']) ? 'selected' : '';
                                echo "<option value='{$month['month']}' $selected>{$month['month']} - {$monthNames[$month['month']]}</option>";
                            }
                        ?>
                    </select>
                </div>
            </div>

            <!-- Other form fields -->

            <div class="col-md-12 form-group">
                <button type="submit" name="submit1" class="btn btn-primary">Check Attendance</button>
                <button type="reset" class="btn btn-default">Reset</button>
            </div>
            <div class="clearfix"> </div>
        </form>


<?php include('footer.php'); ?>
