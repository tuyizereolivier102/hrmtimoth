<?php include('header.php'); ?>

<?php
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();

// Fetch distinct dates from attendance_records
$dateQuery = mysqli_query($db, "SELECT DISTINCT regdate FROM attendance_records");
$dates = array();
while ($row = mysqli_fetch_assoc($dateQuery)) {
    $dates[] = $row['regdate'];
}

// Initialize the $selectedDate variable
$selectedDate = '';

// Check if a date is selected
if (isset($_POST['selectedDate'])) {
    $selectedDate = mysqli_real_escape_string($db, $_POST['selectedDate']);

    // Fetch the existing attendance records for the selected date
    $existingAttendanceQuery = mysqli_query($db, "SELECT EmploiyeeId, attend FROM attendance_records WHERE regdate = '$selectedDate'");
    while ($row = mysqli_fetch_assoc($existingAttendanceQuery)) {
        $attendanceStatus[$row['EmploiyeeId']] = $row['attend'];
    }
}

// Fetch the list of employees
$employeeQuery = mysqli_query($db, "SELECT EmployeeId, CONCAT(FirstName, ' ', LastName) AS FullName FROM employee");
mysqli_data_seek($employeeQuery, 0); // Reset internal pointer

if (isset($_POST['updateAttendance'])) {
    // Get the date and attendance records from the form
    $attendanceDate = mysqli_real_escape_string($db, $_POST['attendanceDate']);
    $attendanceRecords = $_POST['attendance'];

    // Loop through each employee and update their attendance
    foreach ($attendanceRecords as $empid => $attendance) {
        // Update the attendance record for the employee on the given date
        mysqli_query($db, "INSERT INTO attendance_records (EmploiyeeId, attend, regdate)
                            VALUES ('$empid', '$attendance', '$attendanceDate')
                            ON DUPLICATE KEY UPDATE attend = '$attendance'");
    }

    echo "<script>window.alert('Attendance updated successfully.'); window.location='../admin/dashboard.php';</script>";
}
?>

<ol class="breadcrumb" style="margin: 10px 0px !important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>View and Update Attendance</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <form method="POST" action="" enctype="multipart/form-data">
            <!-- Dropdown for selecting date -->
            <div class="col-md-4 control-label">
                <label class="control-label">Select Date:</label>
                <div class="input-group">
                    <span class="input-group-addon">
                        <i class="fa fa-calendar" aria-hidden="true"></i>
                    </span>
                    <select id="selectedDate" name="selectedDate" required>
                        <option value="" disabled selected>-- Select Date --</option>
                        <?php foreach ($dates as $date) : ?>
                            <option value="<?php echo $date; ?>" <?php echo ($selectedDate == $date) ? 'selected' : ''; ?>><?php echo $date; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <!-- Hidden input for current date -->
            <input type="hidden" name="attendanceDate" value="<?php echo date('Y-m-d'); ?>">

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Employee ID</th>
                        <th>Employee Name</th>
                        <th>Attendance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($employee = mysqli_fetch_assoc($employeeQuery)) : ?>
                        <tr>
                            <td><?php echo $employee['EmployeeId']; ?></td>
                            <td><?php echo $employee['FullName']; ?></td>
                            <td>
                                <label class="radio-inline">
                                    <input type="radio" name="attendance[<?php echo $employee['EmployeeId']; ?>]" value="present" <?php echo (isset($attendanceStatus[$employee['EmployeeId']]) && $attendanceStatus[$employee['EmployeeId']] == 'present') ? 'checked' : ''; ?>> Present
                                </label>
                                <label class="radio-inline">
                                    <input type="radio" name="attendance[<?php echo $employee['EmployeeId']; ?>]" value="absent" <?php echo (isset($attendanceStatus[$employee['EmployeeId']]) && $attendanceStatus[$employee['EmployeeId']] == 'absent') ? 'checked' : ''; ?>> Absent
                                </label>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

            <!-- Add a submit button -->
            <div class="col-md-12 form-group">
                <button type="submit" name="updateAttendance" class="btn btn-primary">Update Attendance</button>
                <button type="reset" class="btn btn-default">Reset</button>
            </div>
            <div class="clearfix"></div>
        </form>
    </div>
</div>

<?php include('footer.php'); ?>
