<?php include('header.php'); ?>

<?php
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();

// Fetch all attendance records
$attendanceQuery = mysqli_query($db, "SELECT DISTINCT regdate FROM attendance_records");
?>

<ol class="breadcrumb" style="margin: 10px 0px !important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>View Attendance Date</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <form method="POST" action="" enctype="multipart/form-data">
            <!-- Dropdown for selecting date -->
            

            <!-- Hidden input for current date -->
            <input type="hidden" name="attendanceDate" value="<?php echo date('Y-m-d'); ?>">

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Attendance Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $count = 1;
                    mysqli_data_seek($attendanceQuery, 0); // Reset internal pointer
                    while ($row = mysqli_fetch_assoc($attendanceQuery)) :
                    ?>
                        <tr>
                            <td><?php echo $count++; ?></td>
                            <td><?php echo $row['regdate']; ?></td>
                            <td>
                                <a href="attendance_view.php?dt=<?php echo $row['regdate']; ?>" class="btn btn-primary">View</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

            <!-- Add a submit button -->
            <div class="clearfix"></div>
        </form>
    </div>
</div>

<?php include('footer.php'); ?>
