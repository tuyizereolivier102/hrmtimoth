<?php
include('header.php');

include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();

$attendanceData = array();
$totalPresentDays = 0;
$totalAbsentDays = 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $employeeId = $_POST['empid'];
    $selectedMonth = $_POST['selectedMonth'];

    // Fetch all attendance records for the selected employee and month
    $attendanceQuery = mysqli_query($db, "SELECT * FROM attendance_records WHERE EmploiyeeId = '$employeeId' AND month = '$selectedMonth'");
    
    // Store attendance data in an array and calculate total present and absent days
    while ($row = mysqli_fetch_assoc($attendanceQuery)) {
        $attendanceData[] = $row;
        if ($row['attend'] == 'present') {
            $totalPresentDays++;
        } elseif ($row['attend'] == 'absent') {
            $totalAbsentDays++;
        }
    }
}

?>

<ol class="breadcrumb" style="margin: 10px 0px !important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Attendance Check</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <h3><?php echo ($attendanceData ? "Attendance Records for $selectedMonth Month - Employee ID: $employeeId" : "No Attendance Records Found"); ?></h3>
        <?php if ($attendanceData) : ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Date</th>
                        <th>Status</th>
                        <!-- Add other relevant columns from your attendance_records table -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $count = 1;
                    foreach ($attendanceData as $row) :
                    ?>
                        <tr>
                            <td><?php echo $count++; ?></td>
                            <td><?php echo $row['regdate']; ?></td>
                            <td><?php echo $row['attend']; ?></td>
                            <!-- Add other relevant columns from your attendance_records table -->
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Display total present and absent days -->
            <div>
                <label>Total Present Days: <?php echo $totalPresentDays; ?></label><br>
                <label>Total Absent Days: <?php echo $totalAbsentDays; ?></label>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include('footer.php'); ?>
