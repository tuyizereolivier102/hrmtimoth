<?php include('header.php'); ?>

<?php 
include_once('controller/connect.php');
$dbs = new database();
$db = $dbs->connection();
?>

<ol class="breadcrumb" style="margin: 10px 0px ! important;">
    <li class="breadcrumb-item"><a href="Home.php">Home</a><i class="fa fa-angle-right"></i>Employee Overtime</li>
</ol>

<div class="validation-system" style="margin-top: 0;">
    <div class="validation-form">
        <?php
        error_reporting(0);
        include_once('connect.php');
        $dbs = new database();
        $db = $dbs->connection();

        // Fetch all overtime requests
        $selectAllQuery = "SELECT * FROM overtime";
        $result = mysqli_query($db, $selectAllQuery);

        // Display the HTML table with fetched overtime data
        echo "<table class='table table-bordered'>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Employee ID</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Overtime Hours</th>
                        <th>Overtime Reason</th>
                    </tr>
                </thead>
                <tbody>";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['EmploiyeeId']}</td>
                    <td>{$row['start_time']}</td>
                    <td>{$row['end_time']}</td>
                    <td>{$row['overtime_hours']}</td>
                    <td>{$row['overtime_reason']}</td>
                </tr>";
        }

        echo "</tbody></table>";

        // Close the database connection
        mysqli_close($db);
        ?>
    </div>
</div>

<?php include('footer.php'); ?>
